<?php echo e($slot); ?>

<?php /**PATH F:\XAMPP\htdocs\online-shop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>