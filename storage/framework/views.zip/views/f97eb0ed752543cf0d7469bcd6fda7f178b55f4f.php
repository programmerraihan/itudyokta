<section class="footer">
    <video class="videoBack" src="<?php echo e(asset('frontend/assets/video/4.mp4')); ?> " autoplay loop playsinline muted></video>

    <div class="bg-blur">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <h4>Office Address 1:</h4>
                    <p>
                        <span style="color:#ffd900;font-size:18px;font-weight:bold; margin-right:15px;"><i
                                class="fas fa-map-marker-alt"></i></span>57, Gasroad, Donia, Kodomtoli, Dhaka-1236<br>
                        <span style="color:#ffd900; font-size: 18px; font-weight: bold;margin-right: 15px;"><i
                                class="fas fa-phone"></i></span>09677321618<br>
                        <span style="color:#ffd900; font-size: 18px; font-weight: bold;margin-right: 15px;"><i
                                class="far fa-envelope"></i></span><a href="https://mail.google.com/mail"
                            style="text-decoration:none;">itudyokta@gmail.com</a>
                    </p>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <h4>Office Address 2:</h4>
                    <p>
                        <span style="color:#ffd900;font-size:18px;font-weight:bold; margin-right:15px;"><i
                                class="fas fa-map-marker-alt"></i></span>57, Gasroad, Donia, Kodomtoli, Dhaka-1236<br>
                        <span style="color:#ffd900; font-size: 18px; font-weight: bold;margin-right: 15px;"><i
                                class="fas fa-phone"></i></span>09677321618 <br>
                        <span style="color:#ffd900; font-size: 18px; font-weight: bold;margin-right: 15px;"><i
                                class="far fa-envelope"></i></span><a href="https://mail.google.com/mail"
                            style="text-decoration:none;">itudyokta@gmail.com</a>
                    </p>
                </div>

            </div>

            <div class="social_links">
                <ul>
                    <li class="facebook"><a href="https://www.facebook.com/" style="color:#4267B2;"><i
                                class="fab fa-facebook"></i></a></li>
                    <li class="twitter"><a href="https://www.twitter.com/" style="color:#1DA1F2;"><i
                                class="fab fa-twitter"></i></a></li>
                    <li class="google"><a href="https://www.google.com/" style="color:#ffd900;"><i
                                class="fab fa-google-plus-g"></i></a></li>
                    <li class="instagram"><a href="https://www.instagram.com/" style="color:#C13584;"><i
                                class="fab fa-instagram"></i></a></li>
                    <li class="youtube"><a href="https://www.youtube.com/" style="color:#FF0000;"><i
                                class="fab fa-youtube"></i></a></li>
                </ul>
            </div>

        </div>
        <div class="copyright">
            <p>Copyright © 2016-2022 <span style="color:#ffd900;font-weight: bold;"><a
                        href="https://www.ictknowledge.org/" style="text-decoration: none;">IT UDYOKTA
                        .</a></span></p>
        </div>
    </div>
</section>
<?php /**PATH F:\Code\coxs\resources\views/frontend/body/footer.blade.php ENDPATH**/ ?>