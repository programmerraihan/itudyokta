
<?php $__env->startSection('css'); ?>
    <style type="text/css">
        nav {
            width: 100%;
            z-index: 5;
            text-align: center;
        }

            {
            color: #fff !important;
        }



        nav ul li {
            padding: 10px 10px;
            transition: 0.4s;
        }

        nav ul li a {
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            color: #fff;
        }

        nav ul li .active {
            color: #ffd900;
        }

        nav ul li:hover a {
            color: #fff;
        }

        @media (max-width: 767px) {

            nav {
                /*background: #000;*/
                margin-bottom: 30px;
            }

            nav button {
                background: #f00;
                color: #4e00cc;

            }

        }

        .fixed {
            position: fixed;
            top: 0;
        }

        * {
            box-sizing: border-box;
        }

        #parent {
            color: #fff;
            padding: 10px;
            width: 100%;

            text-align: center;
        }

        .fab {
            padding: 20px;
            font-size: 30px;
            color: #fff;
            width: 50px;
            text-align: center;
            text-decoration: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mian'); ?>
    <?php echo $__env->make('frontend.body.top_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.slide_other', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <section class="title_bar">
        <div class="container">
            <div>
                <h4><i class="fas fa-envelope"></i>About </h4>
            </div>
        </div>
    </section>
    <section class="our_speech " id="our_speech">
        <div class="bg_blur">
            <div class="container">
                <!-- about section -->
                <section class="w3l-about-3 pb-5 pt-2">
                    <div class="container py-md-5 py-4 mb-5">
                        <div class="row align-items-center justify-content-between">
                            <div class="col-lg-6 pr-lg-5">
                                <h3 class="title-big">Join Our Mission to Democratize Education</h3>
                                <p class="mt-3">Consectetur adipiscing elit. Aliquam sit amet
                                    efficitur tortor.Uspendisse efficitur orci urna.</p>
                                <ul class="list-about-2 mt-sm-4 mt-3">
                                    <li class="py-1"><i class="fa fa-check-square-o mr-2" aria-hidden="true"></i>Ut enim
                                        ad minim
                                        veniam</li>
                                    <li class="py-2"><i class="fa fa-check-square-o mr-2" aria-hidden="true"></i>Quis
                                        nostrud
                                        exercitation
                                        ullamco
                                        laboris</li>
                                    <li class="py-1"><i class="fa fa-check-square-o mr-2" aria-hidden="true"></i>Nisi ut
                                        aliquip ex
                                        ea commodo</li>
                                </ul>
                            </div>
                            <div class="col-lg-6 about-2-secs-right mt-lg-0 mt-5">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/galleries/a.jpg')); ?>" alt=""
                                    class="img" />
                            </div>
                        </div>
                    </div>
                </section>
                <!-- //about section -->


                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="content_whole">
                            <div class="content contentEnglish">
                                <p>
                                <p style="text-align:justify;">
                                    একটা
                                    প্রবাদ প্রচলন আছে যা সকলের জানা, "শিক্ষাই
                                    জাতির
                                    মেরুদন্ড"। তবে বর্তমান বিশ্বে উন্নয়নশীল রাষ্ট্র সমূহে সাধারণ যে শিক্ষা
                                    প্রচলন রয়েছে
                                    করতে হলে প্রয়োজন কারিগরী প্রশিক্ষণ। কারণ কোন দেশ
                                    কারিগরী
                                    দক্ষতা ও প্রযুক্তিতে যত বেশি উন্নত, সে দেশের অর্থনীতি ততই শক্তিশালী। কারিগরী
                                    প্রশিক্ষণ প্রচার ও প্রসারে বর্তমানে <span style="color:hsl(0,75%,60%);">গণপ্রজাতন্ত্রী
                                        বাংলাদেশ সরকার</span> ভিশন ২০৪১
                                    সালকে কেন্দ্র করে বহু পদক্ষেপ গ্রহণ করেছেন। অত্র প্রতিষ্ঠান সরকারের
                                    প্রচেষ্টার সাথে
                                    চুয়েট ইঞ্জিনিয়ারিং বিশ্ববিদ্যালয়সহ দেশের বিভিন্ন সরকারি/
                                    বেসরকারি. বাংলাদেশ সরকার</span> ভিশন ২০৪১
                                    সালকে কেন্দ্র করে বহু পদক্ষেপ গ্রহণ করেছেন। অত্র প্রতিষ্ঠান সরকারের
                                    প্রচেষ্টার সাথে
                                    চুয়েট ইঞ্জিনিয়ারিং বিশ্ববিদ্যালয়সহ দেশের বিভিন্ন সরকারি/
                                    বেসরকারি. বাংলাদেশ সরকার</span> ভিশন ২০৪১
                                    সালকে কেন্দ্র করে বহু পদক্ষেপ গ্রহণ করেছেন। অত্র প্রতিষ্ঠান সরকারের
                                    প্রচেষ্টার সাথে
                                    চুয়েট ইঞ্জিনিয়ারিং বিশ্ববিদ্যালয়সহ দেশের বিভিন্ন সরকারি/
                                    বেসরকারি. বাংলাদেশ সরকার</span> ভিশন ২০৪১
                                    সালকে কেন্দ্র করে বহু পদক্ষেপ গ্রহণ করেছেন। অত্র প্রতিষ্ঠান সরকারের
                                    প্রচেষ্টার সাথে
                                    চুয়েট ইঞ্জিনিয়ারিং বিশ্ববিদ্যালয়সহ দেশের বিভিন্ন সরকারি/
                                    বেসরকারি.

                                </p>


                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </div>
    </section>



    <div style="clear: both;"></div>
    &nbsp;
    &nbsp;
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var stickyOffset = $('.sticky').offset().top;

        $(window).scroll(function() {
            var sticky = $('.sticky'),
                scroll = $(window).scrollTop();

            if (scroll >= stickyOffset) sticky.addClass('fixed');
            else sticky.removeClass('fixed');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\coxs\resources\views/frontend/about.blade.php ENDPATH**/ ?>