


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
    <style type="text/css">
        fieldset {
            min-width: 0px;
            padding: 15px;
            margin: 7px;
            border: 2px linear-gradient(to bottom right, #062689, #5b076f);
        }

        legend {
            float: none;
            background-image: linear-gradient(to bottom right, #062689, #5b076f);
            padding: 4px;
            width: 50%;
            color: #000;
            border-radius: 7px;
            font-size: 17px;
            font-weight: 700;
            text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin'); ?>
    <div class="page-content">
        <div class="container-fluid">

            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    
                    <strong><?php echo e($message); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>


            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">Blog</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Layouts</a></li>
                                <li class="breadcrumb-item active">Blog</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="">
                        <div class="">
                            <div class="invoice-title">

                                <h4>
                                    <a href="<?php echo e(route('add.blog')); ?>" class=" float-right btn btn-primary">Add
                                        Blog</a>

                                </h4>


                            </div>

                        </div>
                    </div>
                </div>
            </div>



            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <h4 class="card-title"> Speech info Goers Here</h4>
                            
                            <hr />
                            
                            <table id="blog_table"
                                class="table table-striped table-bordered dt-responsive nowrap  blog_table"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead class="thead-dark">
                                    <tr style="background-image: linear-gradient(to bottom right, #062689, #5b076f);">
                                        <th>SL</th>
                                        <th>Title</th>
                                        
                                        <th>Image</th>
                                        <th>Status</th>

                                        <th class="text-right">Action</th>
                                    </tr>
                                    
                                </thead>

                            </table>

                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>

    <!-- Delete Modal -->
    <div class="modal" id="DeleteModal">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div style="text-align:center; font-size: 14px; color: #9d0000; font-weight: 700;">
                        Are you sure want to delete this Data?
                    </div>

                    <div style="padding: 10px; width: fit-content; margin: auto;">
                        <button type="button" class="btn btn-primary" id="SubmitDeleteForm"
                            style="padding: 2px; width: 50px;">Yes</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal"
                            style="padding: 2px; width: 50px;">No</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="//code.jquery.com/jquery.js"></script>

    <script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#blog_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: '<?php echo e(route('blog.get')); ?>',
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'title',
                        name: 'title'
                    },
                    {
                        data: 'image',
                        name: 'image'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },

                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ]
            });

            var deleteID;
            $('body').on('click', '.delete', function() {
                deleteID = $(this).data('id');
            })
            $('#SubmitDeleteForm').click(function(e) {
                e.preventDefault();

                var id = deleteID;
                var url = "<?php echo e(route('blog.destroy', ':id')); ?>";
                url = url.replace(':id', id);
                console.log(1);
                $.ajax({
                    url: url,
                    method: 'GET',
                    success: function(result) {
                        setTimeout(function() {
                            $('.blog_table').DataTable().ajax.reload(null, false);
                            //   $('#DeleteModal').modal('hide');
                            $("#DeleteModal .close").click()
                        }, 1000);
                    }
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\coxs\resources\views/admin/frontend/blog/index.blade.php ENDPATH**/ ?>