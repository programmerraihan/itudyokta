  <!-- ========== Left Sidebar Start ========== -->
  <div class="vertical-menu">


      <!--- Sidemenu -->
      <div id="sidebar-menu">
          <!-- Left Menu Start -->
          <ul class="metismenu list-unstyled" id="side-menu">


              <li>
                  <a href="javascript: void(0);" class="waves-effect">
                      <i class="bx bx-home-circle"></i><span class="badge badge-pill badge-info float-right">03</span>
                      <span>Dashboards</span>
                  </a>
                  <ul class="sub-menu" aria-expanded="false">
                      <li><a href="index.html">Default</a></li>
                      <li><a href="dashboard-saas.html">Saas</a></li>
                      <li><a href="dashboard-crypto.html">Crypto</a></li>
                  </ul>
              </li>

              <li>
                  <a href="javascript: void(0);" class="has-arrow waves-effect">
                      <i class="bx bx-layout"></i>
                      <span>Information </span>
                  </a>
                  <ul class="sub-menu" aria-expanded="false">
                      <li><a href="<?php echo e(route('add.employee')); ?>">New Employee</a></li>
                      <li><a href="<?php echo e(route('employee.manage')); ?>">Manage Employee</a></li>

                  </ul>
              </li>


              

          </ul>
      </div>
      <!-- Sidebar -->
  </div>
  </div>
<?php /**PATH F:\XAMPP\htdocs\online-shop\resources\views/admin/body/sidebar.blade.php ENDPATH**/ ?>