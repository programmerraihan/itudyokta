<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">
    <div data-simplebar="init" class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li>
                    <a href="javascript: void(0);" class="waves-effect">
                        <i class="bx bx-home-circle"></i><span class="badge badge-pill badge-info float-right">03</span>
                        <span>Dashboards</span>
                    </a>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-dice-d20"></i>
                        <span>Forntend CMS </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">

                        <li><a href="<?php echo e(route('about.index')); ?>">About</a></li>
                        <li><a href="<?php echo e(route('contact.index')); ?>">Contact</a></li>
                        <li><a href="<?php echo e(route('blog.index')); ?>">Blog</a></li>
                        <li><a href="#">Course</a></li>
                        <li><a href="#">Course</a></li>
                        <li><a href="#">Gallery</a></li>
                        <li><a href="#">Notice</a></li>


                        <li><a href="#">log in </a></li>
                        <li><a href="#">Exam Result</a></li>
                        <li><a href="#">Admit Card </a></li>
                        <li><a href="#">Registration Card </a></li>
                        <li><a href="#">Nearby Admission</a></li>
                        <li><a href="#">Online Admission</a></li>
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="dripicons-web"></i>
                        <span>Home </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('home.slide')); ?>">Home Slide</a></li>
                        <li><a href="<?php echo e(route('speech.index')); ?>">Our Speech </a></li>
                        
                        <li><a href="<?php echo e(route('service.index')); ?>">Our Services </a></li>
                        <li><a href="<?php echo e(route('project.index')); ?>">Our Project </a></li>
                        <li><a href="<?php echo e(route('director.index')); ?>">Directors </a></li>
                        <li><a href="<?php echo e(route('gallery.index')); ?>">Gallery </a></li>
                        <li><a href="<?php echo e(route('testimonial.index')); ?>">Testimonial </a></li>
                        <li><a href="<?php echo e(route('achievement.index')); ?>">Our Achievement </a></li>
                        <li><a href="<?php echo e(route('notice.index')); ?>"> Notice </a></li>
                        <li><a href="<?php echo e(route('center.index')); ?>"> Center </a></li>

                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-layout"></i>
                        <span>Branch </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">New Branch</a></li>
                        <li><a href="#">Panding Branch</a></li>
                        <li><a href="#">Branch List</a></li>
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-grid-alt"></i>
                        <span>Academic Modul </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Session</a></li>

                        <li><a href="#">Unit</a></li>
                        <li><a href="#">Bach</a></li>
                        <li><a href="#">Class Schedule</a></li>
                        <li><a href="#">Subject</a></li>
                    </ul>
                </li>

                <li class="menu-title " style="color: #ffd0ad"> &nbsp Admin
                    Section </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-project-diagram"></i>
                        <span>Procurement </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">New Purchase</a></li>
                        <li><a href="#"> Purchase List</a></li>
                        <li><a href="#"> Purchase Report</a></li>

                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-wallet"></i>
                        <span>Account Income</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Add Income</a></li>
                        <li><a href="#">List of Income </a></li>

                        <li><a href="#"> Student Income Report </a></li>
                        <li><a href="#"> Other Income Report </a></li>
                        <li><a href="#"> All Income Report </a></li>

                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="far fa-paper-plane"></i>
                        <span>Account Expense </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Expense Entry</a></li>
                        <li><a href="#">Head Wise Expense</a></li>
                        <li><a href="#"> Expense Report</a></li>
                        <li><a href="#"> Other Report</a></li>

                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-box"></i>
                        <span>Stock Management </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Expense Stock</a></li>
                        <li><a href="#">Stock List</a></li>

                        <li><a href="#">Report Stock</a></li>
                    </ul>
                </li>

                <li class="menu-title " style="color: #ffd0ad"> &nbsp Teacher
                    Section </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-users"></i>
                        <span> Teacher</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Teacher Category</a></li>
                        <li><a href="#">Add Teacher</a></li>
                        <li><a href="#"> Teacher List</a></li>
                        <li><a href="#"> Teacher List</a></li>

                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-cubes"></i>
                        <span> Courses </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('category.index')); ?>">Category List</a></li>
                        <li><a href="<?php echo e(route('course.index')); ?>">Course List</a></li>

                        <li><a href="#"> All Courses</a></li>
                        <li><a href="#"> Active Course</a></li>
                        <li><a href="#"> Pandin Course</a></li>

                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-layout"></i>
                        <span> Marksheet Manage</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Add Mark</a></li>
                    </ul>
                </li>
                <li class="menu-title " style="color: #ffd0ad"> &nbsp Student
                    Section </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-user-graduate"></i>
                        <span>Student </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Student Category</a></li>
                        <li><a href="#">Add Student </a></li>
                        <li><a href="<?php echo e(route('student.index')); ?>">Student List </a></li>
                        <li><a href="#">Student Attendance </a></li>
                        <li><a href="#">Student Attendance Report </a></li>
                        <li><a href="#">Subject Attendance Report </a></li>
                        <li><a href="#">Student Grpup </a></li>
                        <li><a href="#">Student ID Card </a></li>
                        <li><a href="#">Student Detalis </a></li>

                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-question-circle"></i>
                        <span> Quiz</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Question Group</a></li>
                        <li><a href="#">Add Question</a></li>
                        <li><a href="#">Question Bank</a></li>
                        <li><a href="#">Add Question</a></li>
                        <li><a href="#">Add Quiz</a></li>
                        <li><a href="#">Quiz Setup</a></li>

                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-layer"></i>
                        <span> Assignment </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Category</a></li>
                        <li><a href="#">Add Assignment </a></li>
                        <li><a href="#">Assignment List </a></li>

                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-hourglass"></i>
                        <span> Home Work </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Category </a></li>
                        <li><a href="#">Add Home Work </a></li>
                        <li><a href="#">List Home Work</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-vr-cardboard"></i>
                        <span> Live Class</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Zoom Live </a></li>
                        <li><a href="#">Google Met </a></li>

                    </ul>
                </li>
                <li class="menu-title " style="color: #ffd0ad"> &nbsp System
                    Setting </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-user-friends"></i>
                        <span>User Manager </span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Staff</a></li>
                        <li><a href="#">Department</a></li>
                        <li><a href="#">Role</a></li>
                        <li><a href="#">Settings</a></li>
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-cogs"></i>
                        <span>Profile Setting </span>
                    </a>

                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">Staff</a></li>
                        <li><a href="#">Teacher</a></li>
                    </ul>
                </li>


                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="fas fa-viruses"></i>
                        <span>System Setting </span>
                    </a>

                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="#">General Setting </a></li>
                        <li><a href="#">Optional Setting </a></li>
                        <li><a href="#">Academic Year </a></li>
                        <li><a href="#">Week End </a></li>
                        <li><a href="#">Email Setting </a></li>
                        <li><a href="#">SMS Setting </a></li>
                        <li><a href="#">Back Up </a></li>

                    </ul>
                </li>

                <li class="menu-title " style="color: #ffd0ad"> &nbsp STITBD @2022</li>




            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH F:\Code\coxs\resources\views/admin/body/sidebar.blade.php ENDPATH**/ ?>