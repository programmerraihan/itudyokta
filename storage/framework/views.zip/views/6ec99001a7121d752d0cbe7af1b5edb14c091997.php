
<?php $__env->startSection('css'); ?>
    <style type="text/css">
        nav {
            width: 100%;
            z-index: 5;
            text-align: center;
        }

            {
            color: #fff !important;
        }



        nav ul li {
            padding: 10px 10px;
            transition: 0.4s;
        }

        nav ul li a {
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            color: #fff;
        }

        nav ul li .active {
            color: #ffd900;
        }

        nav ul li:hover a {
            color: #fff;
        }

        @media (max-width: 767px) {

            nav {
                /*background: #000;*/
                margin-bottom: 30px;
            }

            nav button {
                background: #f00;
                color: #4e00cc;

            }

        }

        .fixed {
            position: fixed;
            top: 0;
        }

        * {
            box-sizing: border-box;
        }

        #parent {
            color: #fff;
            padding: 10px;
            width: 100%;

            text-align: center;
        }

        .fab {
            padding: 20px;
            font-size: 30px;
            color: #fff;
            width: 50px;
            text-align: center;
            text-decoration: none;
        }

        input[type="month"]::before {
            content: attr(placeholder) !important;
            color: #aaa;
            width: 100%;
        }

        input[type="month"]:focus::before,
        input[type="month"]:active::before {
            content: "";
            width: 0%;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mian'); ?>
    <?php echo $__env->make('frontend.body.top_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.slide_other', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="title_bar">
        <div class="container">
            <div>
                <h4><i class="fas fa-university" style="color: #ffd900"></i> Admission </h4>
            </div>
        </div>
    </section>


    <section class="container">
        <div class="application">
            <form method="POST" action="<?php echo e(route('store.student')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                



                
                <div class="row">
                    <!-- Start Proprietor -->
                    <div class="col-lg-12  col-md-12 col-sm-12 col-xs-12">
                        <h4> Proprietor Information </h4>

                        <input type="text" name="name" class="form-control" placeholder=" Name" class="form-control"
                            required="" oninvalid="this.setCustomValidity('Enter Proprietor Name Here')"
                            oninput="this.setCustomValidity('')">

                        <input type="text" name="father_name" class="form-control" placeholder="  Father's Name"
                            class="form-control" required=""
                            oninvalid="this.setCustomValidity('Enter Proprietor Father`s Name Here')"
                            oninput="this.setCustomValidity('')">

                        <input type="text" name="mother_name" class="form-control" placeholder=" Mother's Name"
                            class="form-control" required=""
                            oninvalid="this.setCustomValidity('Enter Proprietor Mother`s Name Here')"
                            oninput="this.setCustomValidity('')">

                        <input type="text" name="present_address" class="form-control" placeholder=" Present Address"
                            class="form-control" required=""
                            oninvalid="this.setCustomValidity('Enter Proprietor Present Address Here')"
                            oninput="this.setCustomValidity('')">


                        <input type="text" name="permanent_address" class="form-control" placeholder=" Permanent Address"
                            class="form-control" required=""
                            oninvalid="this.setCustomValidity('Enter Proprietor Permanent Address Here')"
                            oninput="this.setCustomValidity('')">


                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

                                <input type="date" name="date" onfocus="(this.type='date')"
                                    onblur="if(!this.value)this.type='text'" class="form-control"
                                    placeholder="Date Of Birth" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Date Of Birth Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <input type="text" name="mobile" class="form-control"
                                    placeholder="Personal Mobile Number" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Personal Mobile Number Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <input type="email" name="email" class="form-control"
                                    placeholder="Personal Email Address" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Personal Email Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <select class="form-select" name="gender" required=""
                                    oninvalid="this.setCustomValidity('Select Your Gender')"
                                    oninput="this.setCustomValidity('')">
                                    <option value="">Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>

                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <select class="form-select" name="religion" required=""
                                    oninvalid="this.setCustomValidity('Select your Religion')"
                                    oninput="this.setCustomValidity('')">
                                    <option value="">Religion</option>
                                    <option value="Islam">Islam</option>
                                    <option value="Sanatan">Sanatan</option>
                                    <option value="Buddhism">Buddhism</option>
                                    <option value="Christian">Christian</option>
                                    <option value="Other">Other</option>
                                </select>

                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <input type="text" name="nationality" placeholder="Nationality" class="form-control"
                                    required="" oninvalid="this.setCustomValidity('Enter Your Roll Number Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>
                        </div>


                        



                        <h4>Academic Information </h4>
                        <div class="row">

                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <input type="text" name="board_name" class="form-control"
                                    placeholder="S.S.C/J.S.C(Board)" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor S.S.C/J.S.C(Board) Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <input type="number" name="roll_no" class="form-control" placeholder="Roll No:"
                                    class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Roll No: Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <input type="number" name="reg_no" class="form-control" placeholder="Reg. No:"
                                    class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Reg. No: Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <input type="text" name="year" class="form-control" placeholder="Year"
                                    class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Year Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <input type="text" name="last_education_board" class="form-control"
                                    placeholder="Last Education" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Last Education Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <input type="number" name="last_education_roll" class="form-control"
                                    placeholder="Roll No:" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Roll No: Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <input type="number" name="last_education_reg" class="form-control"
                                    placeholder="Reg. No:" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Reg. No: Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <input type="text" name="last_education_year" class="form-control" placeholder="Year"
                                    class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Year Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>
                        </div>

                        <h4>Course Information </h4>

                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <select class="form-select" name="course_name" required=""
                                    oninvalid="this.setCustomValidity('Select Name Of Course')"
                                    oninput="this.setCustomValidity('')">
                                    <option value="">Course</option>
                                    <option value="Male">AWS</option>
                                    <option value="Female">Applycation</option>
                                    <option value="Other">Laravel</option>
                                </select>

                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <input type="text" name="month" class="form-control" placeholder="Month"
                                    class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Month & Year Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                            




                        </div>

                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <input type="number" name="price" class="form-control" placeholder=" Course Price"
                                    class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Course Price Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>


                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <input type="number" name="payable_amount" class="form-control"
                                    placeholder="Payable Amount" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Payable Amount Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <input type="number" name="due_amount" class="form-control" placeholder="Deu Amount"
                                    class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Deu Amount Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>




                        </div>

                        <div class="row">


                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <input type="date" name="next_due_date" onfocus="(this.type='date')"
                                    onblur="if(!this.value)this.type='text'" class="form-control"
                                    placeholder=" Next Due Date" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Next Due Date  Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <input type="text" name="batch" class="form-control" placeholder="Batch"
                                    class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Proprietor Batch Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>





                        </div>







                    </div>
                    <!-- End Propritor info -->



                </div>
                <!--  -->

                <div class="row">
                    <h4>Documents</h4>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="input_file">
                            <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" id="profilePhoto">
                            <p> Profile Picture</p>
                        </div>
                        <input type="file" name="image" onchange="profile(event)" class="form-control"
                            required="" oninvalid="this.setCustomValidity('Upload Propritor Image')"
                            oninput="this.setCustomValidity('')">
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="input_file">
                            <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" id="nidCard">
                            <p> NID/Birth Certificate </p>
                        </div>
                        <input type="file" name="nid" onchange="nidInput(event)" class="form-control"
                            required="" oninvalid="this.setCustomValidity('Upload NID Card Copy')"
                            oninput="this.setCustomValidity('')">
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="input_file">
                            <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" id="trade">
                            <p> Certificate S.S.C</p>
                        </div>
                        <input type="file" name="certificate" onchange="tradeInput(event)" class="form-control"
                            required="" oninvalid="this.setCustomValidity('Upload Certificate's Copy')"
                            oninput="this.setCustomValidity('')">
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="input_file">
                            <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" id="signature">
                            <p>Signature</p>
                        </div>
                        <input type="file" name="signature" onchange="signatureInput(event)" class="form-control"
                            required="" oninvalid="this.setCustomValidity('Upload Propritor Valid signature')"
                            oninput="this.setCustomValidity('')">
                    </div>

                </div>


                

                


                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" hidden checked type="radio" name="status"
                            id="inlineCheckbox1" value="1">
                        <label class="form-check-label" hidden for="inlineCheckbox1">Published</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" hidden type="radio" name="status" id="inlineCheckbox2"
                            value="0">
                        <label class="form-check-label" hidden for="inlineCheckbox2">Unpublished</label>
                    </div>
                </div>

                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" hidden checked type="radio" name="student_status"
                            id="inlineCheckbox3" value="0">
                        <label class="form-check-label" hidden for="inlineCheckbox3">Published</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" hidden type="radio" name="student_status" id="inlineCheckbox4"
                            value="1">
                        <label class="form-check-label" hidden for="inlineCheckbox4">Unpublished</label>
                    </div>
                </div>


                <div class="my_glass_button ">
                    <div>
                        <button type="submit"> Apply Now</button>
                    </div>
                </div>
            </form>
        </div>

    </section>

    <div style="clear: both;"></div>
    &nbsp;
    &nbsp;
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var stickyOffset = $('.sticky').offset().top;

        $(window).scroll(function() {
            var sticky = $('.sticky'),
                scroll = $(window).scrollTop();

            if (scroll >= stickyOffset) sticky.addClass('fixed');
            else sticky.removeClass('fixed');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Code\coxs\resources\views/frontend/admission.blade.php ENDPATH**/ ?>