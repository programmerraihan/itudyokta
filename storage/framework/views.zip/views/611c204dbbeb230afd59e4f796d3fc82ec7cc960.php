<section class="Subheader">
    <div class="bg-blur">
        <div class="container">

            <nav class="navbar navbar-expand-md">
                <div class="container-fluid">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-bars"></i>
                    </button>

                </div>
            </nav>
            <div class="header_title">
                <ul>
                    <li>
                        <p class="name"> Youth Development Computer Training Centre</p>


                        <p class="title">Not Only Education, But Also Technology Based Education is Needed...</p>
                    </li>
                </ul>

            </div>

        </div>
    </div>
</section>
<?php /**PATH D:\Code\coxs\resources\views/frontend/body/slide_other.blade.php ENDPATH**/ ?>