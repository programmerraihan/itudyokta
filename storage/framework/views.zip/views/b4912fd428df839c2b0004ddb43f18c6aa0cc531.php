<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">

    <?php $i =1; ?>
    <div class="carousel-inner">

        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($i == '1' ? 'active' : ''); ?>">

                <?php $i++; ?>

                <img src="<?php echo e(asset('frontend/slider/' . $sliderItem->image)); ?>" class="d-block w-100" alt="slider Image">
                <div class="carousel-caption d-none d-md-block">
                    <h5><?php echo e($sliderItem->title); ?></h5>
                    <p><?php echo e($sliderItem->short_title); ?></p>
                    <a href="<?php echo e($sliderItem->link); ?>"> <?php echo e($sliderItem->link); ?></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<?php /**PATH F:\Code\coxs\resources\views/frontend/body/slide.blade.php ENDPATH**/ ?>