
<?php $__env->startSection('css'); ?>
    <style type="text/css">
        nav {
            width: 100%;
            z-index: 5;
            text-align: center;
        }

            {
            color: #fff !important;
        }



        nav ul li {
            padding: 10px 10px;
            transition: 0.4s;
        }

        nav ul li a {
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            color: #fff;
        }

        nav ul li .active {
            color: #ffd900;
        }

        nav ul li:hover a {
            color: #fff;
        }

        @media (max-width: 767px) {

            nav {
                /*background: #000;*/
                margin-bottom: 30px;
            }

            nav button {
                background: #f00;
                color: #4e00cc;

            }

        }

        .fixed {
            position: fixed;
            top: 0;
        }

        * {
            box-sizing: border-box;
        }

        #parent {
            color: #fff;
            padding: 10px;
            width: 100%;

            text-align: center;
        }

        .fab {
            padding: 20px;
            font-size: 30px;
            color: #fff;
            width: 50px;
            text-align: center;
            text-decoration: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mian'); ?>
    <?php echo $__env->make('frontend.body.top_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="our_speech " id="our_speech">
        <div class="bg_blur">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <h1>Our Speech</h1>
                        <div class="content_whole">


                            <div class="content contentEnglish">

                                <p>

                                <p style="text-align:justify;">



                                    <img src="<?php echo e(asset('frontend/speech/' . $speech->image)); ?>" style="height: 250px"
                                        width="681px">
                                    <br />

                                <p><?php echo e($speech->long_text); ?></p>
                                
                                <a href="ourspeech.html"
                                    style="margin: 0px 5px;text-decoration: none;font-weight: bold;">More</a>

                                </p>
                            </div>


                        </div>
                    </div>

                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <div class="regional_notice">
                            <h1> Notices: </h1>
                            <div class="withBtnMore">

                                <div class="notices_box">
                                    <ul>
                                        <li>
                                            <p>“ঈদ মোবারক” “ঈদ মোবারক” দেশব্যাপী সকল প্রশিক্ষণার্থী, আঞ্চলিক
                                                পরিচালক,
                                                শুভাকাঙ্খীসহ মুসলিম উম্মাহর প্রতি রইল ঈদুল ফিতরের শুভেচ্ছা, “ঈদ
                                                মোবারক”
                                                “ঈদ মোবারক” !</p>
                                            <span>Published: 2022-05-02 11:39:35</span><br><br>
                                            <a href="notice/3.html"> <i class="fas fa-plus"> </i> Read More
                                            </a>
                                            <hr>
                                        </li>
                                        <li>
                                            <p>আই.সি.টি নলেজের পক্ষ থেকে সবাইকে জানাই রমজানের শুভেচ্ছা। </p>
                                            <span>Published: 2022-04-11 00:54:09</span><br><br>
                                            <a href="notice/1.html"> <i class="fas fa-plus"> </i> Read More
                                            </a>
                                            <hr>
                                        </li>

                                    </ul>


                                </div>
                                <div class="view_more">
                                    <a href="notices.html"> View All Notices </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </div>
        <!-- Our Speech Read More English POPUP box content -->
        <div class="modal fade" id="englishReadMore" tabindex="-1" aria-labelledby="englishReadMore" aria-hidden="true">
            <div class="modal-dialog modal-dialog">
                <div class="our_speech_model">
                    <div>
                        <h4>Our Speech.</h4>
                        <p>
                            There is a saying that everyone knows, "Education is the backbone of the nation".
                            However,
                            in the age of globalization, people have to be left behind by the education that is
                            common
                            in developing countries in today's world. As a result, the number of unemployed is
                            gradually
                            increasing. Technical education is needed to make any developing country not only in
                            Bangladesh but also in the world free from hunger, poverty and unemployment. Because
                            the
                            more advanced a country is in technical skills and technology, the stronger its
                            economy is.
                            At present, the Government of the People's Republic of Bangladesh has taken many
                            steps in
                            2041 to promote and spread technical education. This institute is carrying out
                            training
                            activities all over the country by expressing solidarity with the efforts of the
                            government.
                            The Ministry of Home Affairs, Ministry of Education, Ministry of Science and
                            Technology,
                            Ministry of Agriculture, Paddy Research Institute, MinistrThere is a saying that
                            everyone
                            knows, "Education is the backbone of the nation". However, in the age of
                            globalization,
                            people have to be left behind by the education that is common in developing
                            countries in
                            today's world. As a result, the number of unemployed is gradually increasing.
                            Technical
                            education is needed to make any developing country not only in Bangladesh but also
                            in the
                            world free from hunger, poverty and unemployment. Because the more advanced a
                            country is in
                            technical skills and technology, the stinistrThere is a saying that everyone knows,
                            "Education is the backbone of the nation". However, in the age of globalization,
                            people have
                            to be left behind by the education that is common in developing countries in today's
                            world.
                            As a result, the number of unemployed is gradually increasing. Technical education
                            is needed
                            to make any developing country not only in Bangladesh but also in the world free
                            from
                            hunger, poverty and unemployment. Because the more advanced a country is in
                            technical skills
                            and technology, the stinistrThere is a saying that everyone knows, "Education is the
                            backbone of the nation". However, in the age of globalization, people have to be
                            left behind
                            by the education that is common in developing countries in today's world. As a
                            result, the
                            number of unemployed is gradually increasing. Technical education is needed to make
                            any
                            developing country not only in Bangladesh but also in the world free from hunger,
                            poverty
                            and unemployment. Because the more advanced a country is in technical skills and
                            technology,
                            the stinistrThere is a saying that everyone knows, "Education is the backbone of the
                            nation". However, in the age of globalization, people have to be left behind by the
                            education that is common in developing countries in today's world. As a result, the
                            number

                        </p>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Our Speech Read More English POPUP box content -->
        <div class="modal fade" id="banglaReadMore" tabindex="-1" aria-labelledby="banglaReadMore" aria-hidden="true">
            <div class="modal-dialog modal-dialog">
                <div class="our_speech_model">
                    <div>
                        <h4 style="font-family:'Shurjo'; ">আমাদের কথা</h4>
                        <p style="font-family:'Shurjo'; ">
                            একটা প্রবাদ প্রচলন আছে যেটি সকলের জানা, "শিক্ষাই জাতির মেরুদন্ড"। তবে বর্তমান বিশ্বে
                            উন্নয়নশীল রাষ্ট্র সমূহে সাধারণ যে শিক্ষা প্রচলন রয়েছে সে শিক্ষা দ্বারা বিশ্বায়নের
                            যুগে
                            মানুষকে পিছিয়ে থাকতে হয়। এতে ক্রমান্বয়ে বেকারত্বের সংখ্যা বেড়েই চলেছে। শুধু
                            বাংলাদেশে নয়
                            বিশ্বের যে কোন উন্নয়নশীল রাষ্ট্রকে ক্ষুধা মুক্ত, দারিদ্র মুক্ত, বেকার মুক্ত করতে হলে
                            প্রয়োজন
                            কারিগরী শিক্ষা। কারণ কোন দেশ কারিগরী দক্ষতা ও প্রযুক্তিতে যত বেশি উন্নত, সে দেশের
                            অর্থনীতি
                            ততই শক্তিশালী। কারিগরী শিক্ষার প্রচার ও প্রসারে বর্তমানে গণপ্রজাতন্ত্রী বাংলাদেশ
                            সরকার ২০৪১
                            সালকে কেন্দ্র করে বহু পদক্ষেপ গ্রহণ করেছেন। অত্র প্রতিষ্ঠান সরকারের প্রচেষ্টার সাথে
                            একাত্মা
                            প্রকাশের মাধ্যমে দেশব্যাপী প্রশিক্ষণ কার্যক্রম চালিয়ে যাচ্ছে। ইতিমধ্যে অত্র


                        </p>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="free_course">
        <div class="bg-blur">
            <div class="container">
                <h1>Off Line Course</h1>

                <div class="row">
                    <?php $__currentLoopData = $offLineCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offLineCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                            <a href="#" style="text-decoration:none;">
                                <div class="my_card">
                                    <img src="<?php echo e(asset('frontend/course/' . $offLineCourse->image)); ?>" class="img">
                                    <div class="card_body">
                                        <h4 class="title"><?php echo e($offLineCourse->title); ?></h4>
                                        <p class="prize">Prize:<?php echo e($offLineCourse->price); ?>/-</p>
                                        <p class="discount_prize"><?php echo e($offLineCourse->offer_price); ?></p>
                                        <span class="total_time"><i class="far fa-clock"></i>
                                            <?php echo e($offLineCourse->video_duration); ?>+ hr </span>
                                        <span class="total_video"><i class="fas fa-video"></i>
                                            <?php echo e($offLineCourse->total_video); ?>+ </span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="my_glass_button">
                <a href="#"> More Off Line Course </a>
            </div>
        </div>
        </div>
    </section>

    <section class="paid_course" id="our_courses">
        <div class="bg-blur">
            <div class="container">
                <h1>Our Paid Courses</h1>

                <div class="row">

                    <?php $__currentLoopData = $onLineCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onLineCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                            <a href="courses/details.html" style="text-decoration:none;">
                                <div class="my_card">
                                    <img src="<?php echo e(asset('frontend/course/' . $onLineCourse->image)); ?>" class="img">
                                    <div class="card_body">
                                        <h4 class="title"><?php echo e($onLineCourse->title); ?> </h4>
                                        <p class="prize">Prize: <?php echo e($onLineCourse->price); ?>/-</p>
                                        <p class="discount_prize">Discount: <?php echo e($onLineCourse->offer_price); ?>/-</p>
                                        <span class="total_time"><i class="far fa-clock"></i>
                                            <?php echo e($onLineCourse->video_duration); ?>+ hr </span>
                                        <span class="total_video"><i class="fas fa-video"></i>
                                            <?php echo e($onLineCourse->total_video); ?>+ </span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>

                <div class="my_glass_button">
                    <a href="courses.html">More Paid Courses </a>
                </div>

            </div>
        </div>
    </section>

    <section class="free_course">
        <div class="bg-blur">
            <div class="container">
                <h1>Our Free Tutorials </h1>
                <div class="row">

                    <?php $__currentLoopData = $freeCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $freeCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                            <a href="#" style="text-decoration:none;">
                                <div class="my_card">
                                    <img src="<?php echo e(asset('frontend/course/' . $freeCourse->image)); ?>" class="img">
                                    <div class="card_body">
                                        <h4 class="title"><?php echo e($freeCourse->title); ?> </h4>
                                        <p class="prize">Prize: <?php echo e($freeCourse->price); ?>/-</p>
                                        <p class="discount_prize">Free</p>
                                        <span class="total_time"><i class="far fa-clock"></i>
                                            <?php echo e($freeCourse->video_duration); ?>+ hr </span>
                                        <span class="total_video"><i class="fas fa-video"></i>
                                            <?php echo e($freeCourse->total_video); ?>+ </span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="my_glass_button">
                <a href="#">More Tutorials </a>
            </div>
        </div>
        </div>
    </section>

    <section class="services" id="our_services">
        <div class="bg-blur">
            <div class="container">
                <h1> Our Services</h1>

                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="service/%e0%a6%95%e0%a6%ae%e0%a7%8d%e0%a6%aa%e0%a6%bf%e0%a6%89%e0%a6%9f%e0%a6%be%e0%a6%b0%20%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%b6%e0%a6%bf%e0%a6%95%e0%a7%8d%e0%a6%b7%e0%a6%a3.html"
                            style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/our_services/1-beadcf.gif')); ?> "
                                    class="img">
                                <div class="card_body">
                                    <h4 class="title_bn">কম্পিউটার প্রশিক্ষণ</h4>
                                    <div class="card_body">
                                        <p class="service_description">
                                            আইটি উদ্যোক্তা ফাউন্ডেশন স্কুল পরিচালিত প্রতিষ্ঠান হতে তিনটি
                                            পদ্ধতিতে কম্পিউটার
                                            প্রশিক্ষণ
                                            গ্রহণ করতে পারেন- (১) আমাদের পরিচালিত যেকোন প্রশিক্ষণ কেন্দ্রে ভর্তি
                                            হয়ে,
                                            (২) অনলাইন ভিডিও টিউটোরিয়াল ক্রয় করে এবং (৩) অনলাইন লাইভ ক্লাসের
                                            মাধ্যমে।...
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="service/%e0%a6%93%e0%a7%9f%e0%a7%87%e0%a6%ac%20%e0%a6%a1%e0%a6%bf%e0%a6%9c%e0%a6%be%e0%a6%87%e0%a6%a8%20%26%20%e0%a6%a1%e0%a7%87%e0%a6%ad%e0%a6%b2%e0%a6%be%e0%a6%aa.html"
                            style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/our_services/2-afdcbe.gif')); ?> "
                                    class="img">
                                <div class="card_body">
                                    <h4 class="title_bn">ওয়েব ডিজাইন &amp; ডেভলাপ</h4>
                                    <div class="card_body">
                                        <p class="service_description">
                                            There are many variations of passages of Lorem Ipsum available, but
                                            the
                                            majority have suffered alteration in some form, by injected humour,
                                            or
                                            randomised words which don&#039;t look even slightly believable. If
                                            you are
                                            going...</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="service/%e0%a6%a1%e0%a7%8b%e0%a6%ae%e0%a7%87%e0%a6%a8%20%26%20%e0%a6%b9%e0%a7%8b%e0%a6%b7%e0%a7%8d%e0%a6%9f%e0%a6%bf%e0%a6%82.html"
                            style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/our_services/3-bcdeaf.gif')); ?> "
                                    class="img">
                                <div class="card_body">
                                    <h4 class="title_bn">ডোমেন &amp; হোষ্টিং</h4>
                                    <div class="card_body">
                                        <p class="service_description">
                                            There are many variations of passages of Lorem Ipsum available, but
                                            the
                                            majority have suffered alteration in some form, by injected humour,
                                            or
                                            randomised words which don&#039;t look even slightly believable. If
                                            you are
                                            going...</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="service/%e0%a6%86%e0%a6%9e%e0%a7%8d%e0%a6%9a%e0%a6%b2%e0%a6%bf%e0%a6%95%20%e0%a6%b6%e0%a6%be%e0%a6%96%e0%a6%be%20%e0%a6%85%e0%a6%a8%e0%a7%81%e0%a6%ae%e0%a7%8b%e0%a6%a6%e0%a6%a8.html"
                            style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/our_services/4-ebacdf.gif')); ?>"
                                    class="img">
                                <div class="card_body">
                                    <h4 class="title_bn">আঞ্চলিক শাখা অনুমোদন</h4>
                                    <div class="card_body">
                                        <p class="service_description">
                                            তৃর্ণমূল পর্যায়ে তথ্য-প্রযুক্তির ছোয়া পৌঁছাতে ও উদ্যোক্তা সৃষ্টির
                                            লক্ষ্যে
                                            দেশব্যাপী কম্পিউটার প্রশিক্ষণ কেন্দ্র অনুমোদন করা হচ্ছে। আপনার কোন
                                            প্রশিক্ষণ
                                            কেন্দ্র আছে? যেটি সরকার/ কারীগরী শিক্ষাবোর্ড অনুমোদিত নয় তবে, আপনি
                                            আম...</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="my_glass_button">
                    <a href="services.html"> More Services </a>
                </div>
                <br>
            </div>
        </div>
    </section>

    <section class="our_project">
        <div class="bg-blur">
            <div class="container">
                <h1>OUR PROJECT </h1>
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/ab.png')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">Online Project </h4>
                                    <p class="service_description">
                                        There are many variations of passages of Lorem Ipsum available, but
                                        the

                                        randomised words which don&#039;t look even slightly believable. If
                                        you are
                                        going...</p>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/abc.jpg')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">Ofline Project </h4>
                                    <p class="service_description">
                                        There are many variations of passages of Lorem Ipsum available, but
                                        the

                                        randomised words which don&#039;t look even slightly believable. If
                                        you are
                                        going...</p>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/abcd.png')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title"> Software </h4>
                                    <p class="service_description">
                                        There are many variations of passages of Lorem Ipsum available, but
                                        the

                                        randomised words which don&#039;t look even slightly believable. If
                                        you are
                                        going...</p>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/abcde.png')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">Development</h4>
                                    <p class="service_description">
                                        There are many variations of passages of Lorem Ipsum available, but
                                        the

                                        randomised words which don&#039;t look even slightly believable. If
                                        you are
                                        going...</p>
                                </div>
                            </div>
                        </a>
                    </div>


                </div>


            </div>

            <div class="my_glass_button">
                <a href="#">More Tutorials </a>
            </div>
        </div>
        </div>
    </section>

    <section class="pt-5 pb-5" style="background: #f5f5f5;">
        <div class="container">
            <div class="row">
                <div class="col-6">
                    <h3 class="mb-3">ALL REGISTERD CENTER </h3>
                </div>
                <div class="col-6 text-right">
                    <a class="btn btn-primary mb-3 mr-1" href="#carouselExampleIndicators2" role="button"
                        data-slide="prev">
                        <i class="fa fa-arrow-left"></i>
                    </a>
                    <a class="btn btn-primary mb-3 " href="#carouselExampleIndicators2" role="button"
                        data-slide="next">
                        <i class="fa fa-arrow-right"></i>
                    </a>
                </div>
                <div class="col-12">
                    <div id="carouselExampleIndicators2" class="carousel slide" data-ride="carousel">

                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="row">

                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1532781914607-2031eca2f00d?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=7c625ea379640da3ef2e24f20df7ce8d">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1517760444937-f6397edcbbcd?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=42b2d9ae6feb9c4ff98b9133addfb698">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1532712938310-34cb3982ef74?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=3d2e8a2039c06dd26db977fe6ac6186a">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1532712938310-34cb3982ef74?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=3d2e8a2039c06dd26db977fe6ac6186a">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>


                            <div class="carousel-item">
                                <div class="row">

                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1532781914607-2031eca2f00d?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=7c625ea379640da3ef2e24f20df7ce8d">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1517760444937-f6397edcbbcd?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=42b2d9ae6feb9c4ff98b9133addfb698">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1532712938310-34cb3982ef74?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=3d2e8a2039c06dd26db977fe6ac6186a">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1532712938310-34cb3982ef74?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=3d2e8a2039c06dd26db977fe6ac6186a">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>


                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1532781914607-2031eca2f00d?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=7c625ea379640da3ef2e24f20df7ce8d">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1517760444937-f6397edcbbcd?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=42b2d9ae6feb9c4ff98b9133addfb698">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1532712938310-34cb3982ef74?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=3d2e8a2039c06dd26db977fe6ac6186a">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <div class="card">
                                            <img class="img-fluid" alt="100%x280"
                                                src="https://images.unsplash.com/photo-1532712938310-34cb3982ef74?ixlib=rb-0.3.5&amp;q=80&amp;fm=jpg&amp;crop=entropy&amp;cs=tinysrgb&amp;w=1080&amp;fit=max&amp;ixid=eyJhcHBfaWQiOjMyMDc0fQ&amp;s=3d2e8a2039c06dd26db977fe6ac6186a">
                                            <div class="card-body">
                                                <h4 class="card-title">Special title treatment</h4>
                                                <p class="card-text">With supporting text below as a natural lead-in to
                                                    additional content.</p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="regional_director" id="our_services">
        <div class="bg-blur">
            <div class="container">
                <h1> Our Board of Directors</h1>

                <div class="row">

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="reg_card">
                            <div class="img_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/images/branches/pic/rename.png')); ?>">
                            </div>

                            <div class="name">
                                <h4>মাহমুদুল হক</h4>
                            </div>
                            <div class="details">
                                <p>
                                    <span class="dir">Chairman </span><br>
                                    <span class="code"> আইটি উদ্যোক্তা ফাউন্ডেশন </span><br>
                                    <span class="add">Dhaka-1236</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="reg_card">
                            <div class="img_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/images/branches/pic/Monirul Alam.jpg')); ?>">
                            </div>

                            <div class="name">
                                <h4>মনিরুল আলম </h4>
                            </div>
                            <div class="details">
                                <p>
                                    <span class="dir">Vice- Chairman</span><br>
                                    <span class="code">আইটি উদ্যোক্তা ফাউন্ডেশন </span><br>
                                    <span class="add">Dhaka-1236</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="reg_card">
                            <div class="img_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/images/branches/pic/Shafiqul Islam.jpg')); ?>">
                            </div>

                            <div class="name">
                                <h4>মুহাম্মদ শফিকুল ইসলাম </h4>
                            </div>
                            <div class="details">
                                <p>
                                    <span class="dir">Executive Director</span><br>
                                    <span class="code">আইটি উদ্যোক্তা ফাউন্ডেশন </span><br>
                                    <span class="add">Dhaka-1236</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="reg_card">
                            <div class="img_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/images/branches/pic/Shahjahan.jpg')); ?>">
                            </div>

                            <div class="name">
                                <h4>মোহাম্মদ শাহজান </h4>
                            </div>
                            <div class="details">
                                <p>
                                    <span class="dir">Treasurer</span><br>
                                    <span class="code">আইটি উদ্যোক্তা ফাউন্ডেশন </span><br>
                                    <span class="add">Dhaka-1236</span>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="my_glass_button">
                    <a href="directors.html"> More Regional Directors </a>
                </div>
                <br>
            </div>
        </div>
    </section>

    <section class="regional_director1" id="our_services">
        <div class="bg-blur">
            <div class="container">
                <h1> Our Regional Directors</h1>

                <div class="row">

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="reg_card">
                            <div class="img_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/images/branches/pic/rename.png')); ?>">
                            </div>

                            <div class="name">
                                <h4>মাহমুদুল হক</h4>
                            </div>
                            <div class="details">
                                <p>
                                    <span class="dir">Chairman </span><br>
                                    <span class="code"> আইটি উদ্যোক্তা ফাউন্ডেশন </span><br>
                                    <span class="add">Dhaka-1236</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="reg_card">
                            <div class="img_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/images/branches/pic/Monirul Alam.jpg')); ?>">
                            </div>

                            <div class="name">
                                <h4>মনিরুল আলম </h4>
                            </div>
                            <div class="details">
                                <p>
                                    <span class="dir">Vice- Chairman</span><br>
                                    <span class="code">আইটি উদ্যোক্তা ফাউন্ডেশন </span><br>
                                    <span class="add">Dhaka-1236</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="reg_card">
                            <div class="img_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/images/branches/pic/Shafiqul Islam.jpg')); ?>">
                            </div>

                            <div class="name">
                                <h4>মুহাম্মদ শফিকুল ইসলাম </h4>
                            </div>
                            <div class="details">
                                <p>
                                    <span class="dir">Executive Director</span><br>
                                    <span class="code">আইটি উদ্যোক্তা ফাউন্ডেশন </span><br>
                                    <span class="add">Dhaka-1236</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="reg_card">
                            <div class="img_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/images/branches/pic/Shahjahan.jpg')); ?>">
                            </div>

                            <div class="name">
                                <h4>মোহাম্মদ শাহজান </h4>
                            </div>
                            <div class="details">
                                <p>
                                    <span class="dir">Treasurer</span><br>
                                    <span class="code">আইটি উদ্যোক্তা ফাউন্ডেশন </span><br>
                                    <span class="add">Dhaka-1236</span>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="my_glass_button">
                    <a href="directors.html"> More Regional Directors </a>
                </div>
                <br>
            </div>
        </div>
    </section>

    <section class="successful_std" id="our_services">
        <div class="bg-blur">
            <div class="container">
                <h1> Our Successful Students</h1>

                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="std_card">
                            <div class="left">
                                <h5>MD. ZAKARIA HUSSAIN</h5>
                                <p>Roll: 220400034</p>
                                <p>Mobile: 01713809081</p>
                                <p style="color: #f00;">Job Title: Accountant</p>
                                <p>Grameen Bank</p>
                            </div>
                            <div class="right">
                                <div class="bg">
                                    <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="std_card">
                            <div class="left">
                                <h5>BURHAN UDDIN</h5>
                                <p>Roll: 220400025</p>
                                <p>Mobile: 01407857560</p>
                                <p style="color: #f00;">Job Title: Computer operator</p>
                                <p>Easy Computer</p>
                            </div>
                            <div class="right">
                                <div class="bg">
                                    <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" style="margin-bottom: 15px;">
                        <div class="std_card">
                            <div class="left">
                                <h5>MD. ALIM UDDIN</h5>
                                <p>Roll: 220400023</p>
                                <p>Mobile: 01765544267</p>
                                <p style="color: #f00;">Job Title: Teacher &amp; Computer Operator</p>
                                <p>DQ International Madrasha</p>
                            </div>
                            <div class="right">
                                <div class="bg">
                                    <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" />
                                </div>
                            </div>
                        </div>
                    </div>



                </div>

                <div class="my_glass_button">
                    <a href="successful/students.html"> More Students </a>
                </div>
                <br>
            </div>
        </div>
    </section>

    <section class="gallery" id="gallery">
        <div class="bg-blur">
            <div class="container">
                <h1>Gallery</h1>
                <div class="row">

                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-left" data-aos-duration="3000">
                        <a href="<?php echo e(asset('frontend/assets/admin/files/galleries/a.jpg')); ?>" data-lightbox="photos"
                            title="এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে,  ছবির বিবরণ ইত্যাদি থাকবে।">
                            <div class="image_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/galleries/a.jpg')); ?>" alt=""
                                    title="" class="img-fluid" />
                                <div class="gallery_details">
                                    <p>এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে, ছবির বিবরণ ইত্যাদি থাকবে। </p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-left" data-aos-duration="3000">
                        <a href="<?php echo e(asset('frontend/assets/admin/files/galleries/aaabb.jpg')); ?>" data-lightbox="photos"
                            title="এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে,  ছবির বিবরণ ইত্যাদি থাকবে।">
                            <div class="image_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/galleries/aaabb.jpg')); ?>" alt=""
                                    title="" class="img-fluid" />
                                <div class="gallery_details">
                                    <p>এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে, ছবির বিবরণ ইত্যাদি থাকবে। </p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-left" data-aos-duration="3000">
                        <a href="<?php echo e(asset('frontend/assets/admin/files/galleries/aab.jpg')); ?>" data-lightbox="photos"
                            title="এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে,  ছবির বিবরণ ইত্যাদি থাকবে।">
                            <div class="image_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/galleries/aab.jpg')); ?>" alt=""
                                    title="" class="img-fluid" />
                                <div class="gallery_details">
                                    <p>এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে, ছবির বিবরণ ইত্যাদি থাকবে। </p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-left" data-aos-duration="3000">
                        <a href="<?php echo e(asset('frontend/assets/admin/files/galleries/aabb.jpg')); ?>" data-lightbox="photos"
                            title="এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে,  ছবির বিবরণ ইত্যাদি থাকবে।">
                            <div class="image_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/galleries/aabb.jpg')); ?>" alt=""
                                    title="" class="img-fluid" />
                                <div class="gallery_details">
                                    <p>এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে, ছবির বিবরণ ইত্যাদি থাকবে। </p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-left" data-aos-duration="3000">
                        <a href="<?php echo e(asset('frontend/assets/admin/files/galleries/aabbcc.jpg')); ?>" data-lightbox="photos"
                            title="এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে,  ছবির বিবরণ ইত্যাদি থাকবে।">
                            <div class="image_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/galleries/aabbcc.jpg')); ?> "
                                    alt="" title="" class="img-fluid" />
                                <div class="gallery_details">
                                    <p>এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে, ছবির বিবরণ ইত্যাদি থাকবে। </p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-left" data-aos-duration="3000">
                        <a href="<?php echo e(asset('frontend/assets/admin/files/galleries/aabbvvcc.jpg')); ?>"
                            data-lightbox="photos"
                            title="এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে,  ছবির বিবরণ ইত্যাদি থাকবে।">
                            <div class="image_box">
                                <img src="<?php echo e(asset('frontend/assets/admin/files/galleries/aabbvvcc.jpg')); ?>"
                                    alt="" title="" class="img-fluid" />
                                <div class="gallery_details">
                                    <p>এখানে ছবির ক্যাপশন হবে। ছবি কখন তোলা হয়েছে, ছবির বিবরণ ইত্যাদি থাকবে। </p>
                                </div>
                            </div>
                        </a>
                    </div>

                </div>
                <div class="my_glass_button">
                    <a href="gallery.html"> Go To Gallery </a>
                </div>

            </div>
        </div>
        </div>
    </section>


    <section class="testimonials_area">
        <div class="container">
            <div class="testi">
                <h1>Testimonials</h1>

                <div class="row" data-aos="fade-right" data-aos-duration="3000">
                    <div class="col-md-12">
                        <div id="testimonial-slider" class="owl-carousel">

                            <div class="testimonial">

                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="left">
                                            <div class="pic">
                                                <img
                                                    src="<?php echo e(asset('frontend/assets/admin/images/testimonial/image/220824043211.jpg')); ?>">
                                            </div>
                                            <p class="title">Government of the People&#039;s Republic of Bangladesh
                                            </p>
                                            <span class="post">Registrar of Joint Stock Companies &amp; Firms</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="right">
                                            <a href="<?php echo e(asset('frontend/assets/admin/images/testimonial/doc/11223.jpg')); ?>"
                                                data-lightbox="photos" title="">
                                                <img
                                                    src="<?php echo e(asset('frontend/assets/admin/images/testimonial/doc/11223.jpg')); ?>">
                                                <!-- <p></p> -->
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="testimonial">

                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="left">
                                            <div class="pic">
                                                <img
                                                    src="<?php echo e(asset('frontend/assets/admin/images/testimonial/image/logo.jpg')); ?> ">
                                            </div>
                                            <p class="title">Name Of Derector</p>
                                            <span class="post">Dhaka Bangladesh </span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="right">
                                            <a href="<?php echo e(asset('frontend/assets/admin/images/testimonial/doc/1122.jpg')); ?> "
                                                data-lightbox="photos" title="">
                                                <img
                                                    src="<?php echo e(asset('frontend/assets/admin/images/testimonial/doc/1122.jpg')); ?> ">
                                                <!-- <p></p> -->
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>


                        </div>
                    </div>
                </div>
            </div>
    </section>
    


    <div style="clear: both;"></div>

    <section class="goal_area">
        <div class="bg-blur">
            <div class="container">
                <h1 style="color:#fff;">
                    Our Achievement
                </h1>
                <div class="row" data-aos="fade-down" data-aos-duration="3000">
                    <div class=" col-md-3 col-sm-6 col-xs-6">
                        <div class="box">
                            <span class="icon"><i class="fa fa-graduation-cap"></i></span>
                            <span class="counter"> 6110 </span><span style="color:#ffd900;font-weight: bold;">+</span>
                            <p>Completed Students</p>
                        </div>
                    </div>

                    <div class=" col-md-3 col-sm-6 col-xs-6">
                        <div class="box">
                            <span class="icon"><i class="fas fa-chalkboard-teacher"></i></span>

                            <span class="counter">104</span><span style="color:#ffd900;font-weight: bold;">+</span>
                            <p>Expert Instructors</p>
                        </div>
                    </div>

                    <div class=" col-md-3 col-sm-6 col-xs-6">
                        <div class="box">

                            <span class="icon"><i class="fa fa-film" aria-hidden="true"></i></span>
                            <span class="counter">10</span><span style="color:#ffd900;font-weight: bold;">+</span>
                            <p>Tutorials in our store</p>
                        </div>
                    </div>

                    <div class=" col-md-3 col-sm-6 col-xs-6">
                        <div class="box">

                            <span class="icon"><i class="fa fa-briefcase" aria-hidden="true"></i></span>
                            <span class="counter">27</span><span style="color:#ffd900;font-weight: bold;">+</span>
                            <p>Students get employed</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="callback_area" id="feedback">
        <div class="bg-blur">
            <div class="container">
                <div class="row">
                    <h1>
                        Request A Callback
                    </h1>
                </div>
                <div class="callback_location">
                    <div class="row ">
                        <div class="callback_form col-md-6 col-sm-6 col-xs-12" data-aos="fade-right"
                            data-aos-duration="3000">
                            <form method="POST" action="https://www.ictknowledgebd.org/message/sent">
                                <input type="hidden" name="_token" value="ZpxnafwdfmNooNKmhFPPb76yA0tfuzdQtWkWQDfI">
                                <div class="form-group">
                                    <input class="form-control" placeholder="Your Name" required
                                        name="name"type="text">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Your E-mail" required name="email"
                                        type="email">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Mobile No." required name="phone"
                                        type="number">
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control textarea" placeholder="Your Message..." rows="3" required name="message"
                                        cols="50"></textarea>
                                </div>
                                <div class="my_glass_button">
                                    <input type="submit" class="my_btns" value="Send Message">
                                </div>

                            </form>
                        </div>

                        <div class="location col-md-6 col-sm-6 col-xs-12" data-aos="fade-left" data-aos-duration="3000">
                            <!-- <img src="img/location.jpg"> -->
                            

                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7306.565581460718!2d90.43400282664588!3d23.701593365542756!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b9da4a476275%3A0x976b322054ef01a1!2sDoniya%2C%20Dhaka!5e0!3m2!1sen!2sbd!4v1665398258791!5m2!1sen!2sbd"
                                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>

                        </div>
                    </div>
                </div> <!-- // callback_location -->
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var stickyOffset = $('.sticky').offset().top;

        $(window).scroll(function() {
            var sticky = $('.sticky'),
                scroll = $(window).scrollTop();

            if (scroll >= stickyOffset) sticky.addClass('fixed');
            else sticky.removeClass('fixed');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Code\coxs\resources\views/frontend/index.blade.php ENDPATH**/ ?>