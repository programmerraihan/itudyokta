


<?php $__env->startSection('css'); ?>
    <style type="text/css">
        fieldset {
            min-width: 0px;
            padding: 15px;
            margin: 7px;
            border: 2px solid #a66df5;
        }

        legend {
            float: none;
            background-image: linear-gradient(to bottom right, #062689, #5b076f);
            padding: 4px;
            width: 50%;
            color: rgb(255, 255, 255);
            border-radius: 7px;
            font-size: 17px;
            font-weight: 700;
            text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin'); ?>
    <div class="page-content">
        <div class="container-fluid">

            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    
                    <strong><?php echo e($message); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>


            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">Add Student</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Layouts</a></li>
                                <li class="breadcrumb-item active">Add Student</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="">
                        <div class="">
                            <div class="invoice-title">

                                <h4>
                                    <a href="<?php echo e(route('student.index')); ?>" class=" float-right btn btn-primary">Student</a>
                                </h4>


                            </div>

                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <form method="POST" action="<?php echo e(route('store.student')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
    

                <div class="col-lg-12">
                    <fieldset>
                        <legend>Personal Information
                        </legend>
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body ">


                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="name">Name <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="name" class="form-control" id="name">

                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="father_name">Father's Name <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="father_name" class="form-control"
                                                    id="father_name">

                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="mother_name">Mother's Name <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="mother_name" class="form-control"
                                                    id="mother_name">

                                            </div>
                                        </div>

                                    </div>





                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="present_address"> Present Address <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="present_address" placeholder=" Present Address"
                                                    class="form-control" id="present_address">

                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="permanent_address"> Permanent Address <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="permanent_address"
                                                    placeholder=" Permanent Address" class="form-control"
                                                    id="permanent_address">

                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="date"> Date Of Birth <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="date" placeholder=" Date Of Birth"
                                                    class="form-control" id="date">

                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="mobile">Personal Mobile Number <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="mobile"
                                                    placeholder=" Personal Mobile Number" class="form-control"
                                                    id="mobile">

                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="email">Personal Email <span class="text-danger">*</span>
                                                </label>
                                                <input type="email" name="email" placeholder="Personal Email "
                                                    class="form-control" id="email">

                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="formrow-inputState">Gender<span class="text-danger">*</span>
                                                </label>
                                                <select id="formrow-inputState" name="gender" class="form-control">
                                                    <option value="" disabled selected>-- Select Gender --
                                                    </option>

                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                    <option value="Other">Other</option>
                                                </select>

                                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="formrow-inputState">Religion<span class="text-danger">*</span>
                                                </label>
                                                <select id="formrow-inputState" name="religion" class="form-control">
                                                    <option value="" disabled selected>-- Select Religion --
                                                    </option>

                                                    <option value="Islam">Islam</option>
                                                    <option value="Sanatan">Sanatan</option>
                                                    <option value="Buddhism">Buddhism</option>
                                                    <option value="Christian">Christian</option>
                                                    <option value="Other">Other</option>
                                                </select>

                                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>



                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="nationality">Nationality <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="nationality" placeholder="Nationality"
                                                    class="form-control" id="nationality">

                                            </div>
                                        </div>
                                    </div>








                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>


                <div class="col-lg-12">
                    <fieldset>
                        <legend>Academic Information</legend>
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body ">


                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="board_name">S.S.C/J.S.C(Board) <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="board_name" placeholder="S.S.C/J.S.C(Board)"
                                                    class="form-control" id="board_name">

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="roll_no">Roll No <span class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="roll_no" placeholder="Roll No:"
                                                    class="form-control" id="roll_no">

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="reg_no">Reg. No: <span class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="reg_no" placeholder="Reg. No:"
                                                    class="form-control" id="reg_no">

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="year">Year <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="year" placeholder="Year"
                                                    class="form-control" id="year">

                                            </div>
                                        </div>

                                    </div>


                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="last_education_board">Last Education <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="last_education_board"
                                                    placeholder="Last Education (Board)" class="form-control"
                                                    id="last_education_board">

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="last_education_roll">Roll No <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="last_education_roll" placeholder="Roll No:"
                                                    class="form-control" id="last_education_roll">

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="last_education_reg">Reg. No: <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="last_education_reg" placeholder="Reg. No:"
                                                    class="form-control" id="last_education_reg">

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="last_education_year">Year <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="last_education_year" placeholder="Year"
                                                    class="form-control" id="last_education_year">

                                            </div>
                                        </div>

                                    </div>







                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>

                <div class="col-lg-12">
                    <fieldset>
                        <legend>Course Information</legend>
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body ">


                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="formrow-inputState">Course<span class="text-danger">*</span>
                                                </label>
                                                <select id="formrow-inputState" name="courseTitle_id" class="form-control">
                                                    <option value="" disabled selected>-- Select Course --
                                                    </option>
                                                    
                                                        <?php $__currentLoopData = $courseTitles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($courseTitle->id); ?>"> <?php echo e($courseTitle->title); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php $__errorArgs = ['course'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="month">Month <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="month" placeholder="Month"
                                                    class="form-control" id="month">

                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="price">Price <span class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="price" placeholder="Price"
                                                    class="form-control" id="price">

                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="payable_amount">Payable Amount <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="payable_amount" placeholder="Payable Amount"
                                                    class="form-control" id="payable_amount">

                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="due_amount">Due Amount<span class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="due_amount" placeholder="Due Amount"
                                                    class="form-control" id="due_amount">

                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="next_due_date">Next Due Date <span
                                                        class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="next_due_date" placeholder="Next Due Date"
                                                    class="form-control" id="next_due_date">
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="batch">Batch <span class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="batch" placeholder="Batch"
                                                    class="form-control" id="batch">
                                            </div>
                                        </div>

                                    </div>



                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>

                <div class="col-lg-12">
                    <fieldset>
                        <legend>Documents</legend>
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body ">



                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div class="input_file">
                                                    <label for="image">Profile Picture <span
                                                            class="text-danger">*</span>
                                                    </label>
                                                </div>
                                                <input type="file" name="image" placeholder="Profile Picture"
                                                    class="form-control" id="image">

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div class="input_file">
                                                    <label for="nid">NID <span
                                                            class="text-danger">*</span>
                                                    </label>
                                                </div>
                                                <input type="file" name="nid" placeholder="NID"
                                                    class="form-control" id="nid">

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div class="input_file">
                                                    <label for="certificate">Certificate <span
                                                            class="text-danger">*</span>
                                                    </label>
                                                </div>
                                                <input type="file" name="certificate" placeholder="Price"
                                                    class="form-control" id="certificate">

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div class="input_file">
                                                    <label for="signature">Signature <span
                                                            class="text-danger">*</span>
                                                    </label>
                                                </div>
                                                <input type="file" name="signature" placeholder="Signature"
                                                    class="form-control" id="signature">

                                            </div>
                                        </div>

                                    </div>




                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>

                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" hidden checked type="radio" name="status"
                            id="inlineCheckbox1" value="1">
                        <label class="form-check-label" hidden for="inlineCheckbox1">Published</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" hidden type="radio" name="status" id="inlineCheckbox2"
                            value="0">
                        <label class="form-check-label" hidden for="inlineCheckbox2">Unpublished</label>
                    </div>
                </div>

                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" hidden checked type="radio" name="student_status"
                            id="inlineCheckbox3" value="0">
                        <label class="form-check-label" hidden for="inlineCheckbox3">Published</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" hidden type="radio" name="student_status" id="inlineCheckbox4"
                            value="1">
                        <label class="form-check-label" hidden for="inlineCheckbox4">Unpublished</label>
                    </div>
                </div>


                <div class="col-lg-12">
                    <fieldset>
                        <legend>To Be Filled up by Cox's Online Dot Com</legend>
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body ">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div class="input_file">
                                                    <label for="reg_no_student">Reg. No: <span
                                                            class="text-danger">*</span>
                                                    </label>
                                                </div>
                                                <input type="numer" name="reg_no_student" placeholder="Price"
                                                    class="form-control" id="reg_no_student">

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div class="input_file">
                                                    <label for="roll_no_student">Roll No: <span
                                                            class="text-danger">*</span>
                                                    </label>
                                                </div>
                                                <input type="numer" name="roll_no_student" placeholder="Price"
                                                    class="form-control" id="roll_no_student">

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div class="input_file">
                                                    <label for="session">Session <span class="text-danger">*</span>
                                                    </label>
                                                </div>
                                                <input type="text" name="session" placeholder="Session"
                                                    class="form-control" id="session">

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div class="input_file">
                                                    <label for="signature_director">Signature of Center Director<span
                                                            class="text-danger">*</span>
                                                    </label>
                                                </div>
                                                <input type="file" name="signature_director" placeholder="Price"
                                                    class="form-control" id="signature_director">

                                            </div>
                                        </div>

                                    </div>

                                </div>
                                
                            </div>
                        </div>
                    </fieldset>
                </div>

                &nbsp;
                &nbsp;

                   <div class="col-lg-12">
                        <div class="col-lg-12">
                            
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="text-center">
                                                <button type="submit" class="btn btn-primary">ADD
                                                    STUDENT </button>
                                                </div>
                                            </div>
                                        </div>
                                    
                            </div>
                        </div>
                    </div>
                    &nbsp;


                




                </form>
            
                </div>


        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\coxs\resources\views/admin/student/add.blade.php ENDPATH**/ ?>