<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH F:\Code\coxs\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>