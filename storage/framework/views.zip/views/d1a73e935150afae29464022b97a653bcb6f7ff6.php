<nav class="navbar navbar-expand-lg navbar-light bg-light sticky">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(asset('frontend/assets/image/logo.png')); ?>">IT
            UDYOKTA</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav  ms-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" aria-current="page"
                        href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('about') ? 'active' : ''); ?>" href="<?php echo e(url('/about')); ?>">
                        ABOUT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('course') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/course')); ?>">COURSE</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('admission') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/admission')); ?>">ADMISSION</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('online-exam') ? 'active' : ''); ?> "
                        href="<?php echo e(url('/online-exam')); ?>">ONLINE EXAM</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('result') ? 'active' : ''); ?> "
                        href="<?php echo e(url('/result')); ?>">RESULT</a>
                </li>


                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('center-registration') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/center-registration')); ?>">CENTER REGISTRATION</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('blog') ? 'active' : ''); ?>" href="<?php echo e(url('/blog')); ?>">
                        BLOG</a>
                </li>


                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('contact') ? 'active' : ''); ?>" href="<?php echo e(url('/contact')); ?>">
                        CONTACT
                        US </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\Code\coxs\resources\views/frontend/body/navbar.blade.php ENDPATH**/ ?>