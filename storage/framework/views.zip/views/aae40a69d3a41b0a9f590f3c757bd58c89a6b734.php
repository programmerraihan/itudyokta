<div class="col-lg-12" style="height: 45px; background:#f5be0b">

    <div class="container">
        <div class="row ">

            <div class="col-lg-3 col-md-5 col-7">
                <div id="parent">
                    <div id="social_media">
                        <p class=" mb-0" style="color: #0056b3 !important">
                            <i class="far fa-clock"></i>
                            Mon-Fri 10:00-19:00
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-2 col-md-3 col-5">

                <div id="parent">
                    <div id="social_media">
                        <p class="mb-0">
                            <a href="tel: 110-101-101" class="" style="color: #0056b3 !important">
                                <i class="fa fa-phone "></i>
                                110-101-101
                            </a>
                        </p>

                    </div>
                </div>
            </div>



            <div class="col-lg-3 col-md-3 col-12 ms-auto">
                <div id="parent">
                    <div id="social_media">

                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-pinterest"></i></a>
                    </div>
                </div>
            </div>



        </div>
    </div>

</div>
<?php /**PATH F:\Code\coxs\resources\views/frontend/body/top_header.blade.php ENDPATH**/ ?>