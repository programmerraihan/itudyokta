
<?php $__env->startSection('css'); ?>
    <style type="text/css">
        nav {
            width: 100%;
            z-index: 5;
            text-align: center;
        }

            {
            color: #fff !important;
        }



        nav ul li {
            padding: 10px 10px;
            transition: 0.4s;
        }

        nav ul li a {
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            color: #fff;
        }

        nav ul li .active {
            color: #ffd900;
        }

        nav ul li:hover a {
            color: #fff;
        }

        @media (max-width: 767px) {

            nav {
                /*background: #000;*/
                margin-bottom: 30px;
            }

            nav button {
                background: #f00;
                color: #4e00cc;

            }

        }

        .fixed {
            position: fixed;
            top: 0;
        }

        * {
            box-sizing: border-box;
        }

        #parent {
            color: #fff;
            padding: 10px;
            width: 100%;

            text-align: center;
        }

        .fab {
            padding: 20px;
            font-size: 30px;
            color: #fff;
            width: 50px;
            text-align: center;
            text-decoration: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mian'); ?>
    <?php echo $__env->make('frontend.body.top_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.slide_other', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="title_bar">
        <div class="container">
            <div>
                <h4><i class="fas fa-university"></i> New Centre Registration </h4>
            </div>
        </div>
    </section>



    <section class="container">
        <form method="POST" action="https://www.ictknowledgebd.org/application/store" class="application"
            enctype="multipart/form-data">
            <input type="hidden" name="_token" value="ZpxnafwdfmNooNKmhFPPb76yA0tfuzdQtWkWQDfI">
            <div class="row">
                <!-- Start Proprietor -->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <h4> Proprietor Information </h4>

                    <input type="text" name="director" class="form-control" placeholder=" Name" class="form-control"
                        required="" oninvalid="this.setCustomValidity('Enter Proprietor Name Here')"
                        oninput="this.setCustomValidity('')">

                    <input type="text" name="director_father" class="form-control" placeholder="  Father's Name"
                        class="form-control" required=""
                        oninvalid="this.setCustomValidity('Enter Proprietor Father`s Name Here')"
                        oninput="this.setCustomValidity('')">

                    <input type="text" name="director_mother" class="form-control" placeholder=" Mother's Name"
                        class="form-control" required=""
                        oninvalid="this.setCustomValidity('Enter Proprietor Mother`s Name Here')"
                        oninput="this.setCustomValidity('')">

                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <input type="text" name="director_mobile" class="form-control"
                                placeholder="Personal Mobile Number" class="form-control" required=""
                                oninvalid="this.setCustomValidity('Enter Proprietor Personal Mobile Number Here')"
                                oninput="this.setCustomValidity('')">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <input type="email" name="director_email" class="form-control"
                                placeholder="Personal Email Address" class="form-control" required=""
                                oninvalid="this.setCustomValidity('Enter Proprietor Personal Email Here')"
                                oninput="this.setCustomValidity('')">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <select class="form-select" name="director_gender" required=""
                                oninvalid="this.setCustomValidity('Select Your Gender')"
                                oninput="this.setCustomValidity('')">
                                <option value="">Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>

                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <select class="form-select" name="director_religion" required=""
                                oninvalid="this.setCustomValidity('Select your Religion')"
                                oninput="this.setCustomValidity('')">
                                <option value="">Religion</option>
                                <option value="Islam">Islam</option>
                                <option value="Sanatan">Sanatan</option>
                                <option value="Buddhism">Buddhism</option>
                                <option value="Christian">Christian</option>
                                <option value="Other">Other</option>
                            </select>

                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <input type="text" name="director_nationality" placeholder="Nationality" class="form-control"
                                required="" oninvalid="this.setCustomValidity('Enter Your Roll Number Here')"
                                oninput="this.setCustomValidity('')">
                        </div>
                    </div>


                    <div class="row">

                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <select class="form-select" name="state_id" required=""
                                oninvalid="this.setCustomValidity('Select Your Division')"
                                oninput="this.setCustomValidity('')">
                                <option value="">Division</option>
                                <option value="1"> Dhaka Division</option>
                                <option value="2"> Chittagong Division</option>
                                <option value="3"> Rajshahi Division</option>
                                <option value="4"> Khulna Division</option>
                                <option value="5"> Sylhet Division</option>
                                <option value="6"> Mymensing Division</option>
                                <option value="7"> Rangpur Division</option>
                                <option value="8"> Barisal Division</option>
                            </select>

                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <select class="form-select" name="district_id" required=""
                                oninvalid="this.setCustomValidity('Select Your Division')"
                                oninput="this.setCustomValidity('')">
                                <option value="">District</option>
                                <option value="1"> Comilla</option>
                                <option value="2"> Feni</option>
                                <option value="3"> Brahmanbaria</option>
                                <option value="4"> Rangamati</option>
                                <option value="5"> Noakhali</option>
                                <option value="6"> Chandpur</option>
                                <option value="7"> Lakshmipur</option>
                                <option value="8"> Chattogram</option>
                                <option value="9"> Coxsbazar</option>
                                <option value="10"> Khagrachhari</option>
                                <option value="11"> Bandarban</option>
                                <option value="12"> Sirajganj</option>
                                <option value="13"> Pabna</option>
                                <option value="14"> Bogura</option>
                                <option value="15"> Rajshahi</option>
                                <option value="16"> Natore</option>
                                <option value="17"> Joypurhat</option>
                                <option value="18"> Chapainawabganj</option>
                                <option value="19"> Naogaon</option>
                                <option value="20"> Jashore</option>
                                <option value="21"> Satkhira</option>
                                <option value="22"> Meherpur</option>
                                <option value="23"> Narail</option>
                                <option value="24"> Chuadanga</option>
                                <option value="25"> Kushtia</option>
                                <option value="26"> Magura</option>
                                <option value="27"> Khulna</option>
                                <option value="28"> Bagerhat</option>
                                <option value="29"> Jhenaidah</option>
                                <option value="30"> Jhalakathi</option>
                                <option value="31"> Patuakhali</option>
                                <option value="32"> Pirojpur</option>
                                <option value="33"> Barisal</option>
                                <option value="34"> Bhola</option>
                                <option value="35"> Barguna</option>
                                <option value="36"> Sylhet</option>
                                <option value="37"> Moulvibazar</option>
                                <option value="38"> Habiganj</option>
                                <option value="39"> Sunamganj</option>
                                <option value="40"> Narsingdi</option>
                                <option value="41"> Gazipur</option>
                                <option value="42"> Shariatpur</option>
                                <option value="43"> Narayanganj</option>
                                <option value="44"> Tangail</option>
                                <option value="45"> Kishoreganj</option>
                                <option value="46"> Manikganj</option>
                                <option value="47"> Dhaka</option>
                                <option value="48"> Munshiganj</option>
                                <option value="49"> Rajbari</option>
                                <option value="50"> Madaripur</option>
                                <option value="51"> Gopalganj</option>
                                <option value="52"> Faridpur</option>
                                <option value="53"> Panchagarh</option>
                                <option value="54"> Dinajpur</option>
                                <option value="55"> Lalmonirhat</option>
                                <option value="56"> Nilphamari</option>
                                <option value="57"> Gaibandha</option>
                                <option value="58"> Thakurgaon</option>
                                <option value="59"> Rangpur</option>
                                <option value="60"> Kurigram</option>
                                <option value="61"> Sherpur</option>
                                <option value="62"> Mymensingh</option>
                                <option value="63"> Jamalpur</option>
                                <option value="64"> Netrokona</option>
                            </select>

                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <select class="form-select" name="city_id" required=""
                                oninvalid="this.setCustomValidity('Select Your City')"
                                oninput="this.setCustomValidity('')">
                                <option value="">City</option>
                                <option value="1"> Barguna</option>
                                <option value="2"> Barisal</option>
                                <option value="3"> Bhola</option>
                                <option value="4"> Jhalkati</option>
                                <option value="5"> Potuakhali</option>
                                <option value="6"> Pirojpur</option>
                                <option value="7"> Bandorbun</option>
                                <option value="8"> Brammonbaria</option>
                                <option value="9"> Chandpur</option>
                                <option value="10"> Chittagong</option>
                                <option value="11"> Comilla</option>
                                <option value="12"> Cox&#039;s Bazar</option>
                                <option value="13"> Feni</option>
                                <option value="14"> Khagrachari</option>
                                <option value="15"> Laxmipur</option>
                                <option value="16"> Noakhali</option>
                                <option value="17"> Rangamati</option>
                                <option value="18"> Dhaka</option>
                                <option value="19"> Faridpur</option>
                                <option value="20"> Gazipur</option>
                                <option value="21"> Gopalganj</option>
                                <option value="22"> Kishorganj</option>
                                <option value="23"> Madaripur</option>
                                <option value="24"> Manikganj</option>
                                <option value="25"> Munshiganj</option>
                                <option value="26"> Narayanganj</option>
                                <option value="27"> Narshingdi</option>
                                <option value="28"> Rajbari</option>
                                <option value="29"> Shariatpur</option>
                                <option value="30"> Tangail</option>
                                <option value="31"> Bagerhat</option>
                                <option value="32"> Chuadanga</option>
                                <option value="33"> Jessore</option>
                                <option value="34"> Jhinaidaha</option>
                                <option value="35"> Khulna</option>
                                <option value="36"> Kushtia</option>
                                <option value="37"> Magura</option>
                                <option value="38"> Meherpur</option>
                                <option value="39"> Norail</option>
                                <option value="40"> Sathkira</option>
                                <option value="41"> Jamalpur</option>
                                <option value="42"> Netrokuna</option>
                                <option value="43"> Mymensing</option>
                                <option value="44"> Sherpur</option>
                                <option value="45"> Bogra</option>
                                <option value="46"> Joypurhat</option>
                                <option value="47"> Nouga</option>
                                <option value="48"> Nator</option>
                                <option value="49"> Nobabgonj</option>
                                <option value="50"> Pabna</option>
                                <option value="51"> Rajshahi</option>
                                <option value="52"> Shirajganj</option>
                                <option value="53"> Dinajpur</option>
                                <option value="54"> Gaibanda</option>
                                <option value="55"> Kurigram</option>
                                <option value="56"> Lalmonirhat</option>
                                <option value="57"> Nilfamari</option>
                                <option value="58"> Panchogor</option>
                                <option value="59"> Rangpur</option>
                                <option value="60"> Tegorgaon</option>
                                <option value="61"> Hobiganj</option>
                                <option value="62"> Moulovibazar</option>
                                <option value="63"> Sunamganj</option>
                                <option value="64"> Sylhet</option>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <input type="text" name="director_upazila" class="form-control" placeholder="Upazila"
                                class="form-control" required=""
                                oninvalid="this.setCustomValidity('Enter Proprietor Upazila Here')"
                                oninput="this.setCustomValidity('')">
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <input type="text" name="director_post_office" class="form-control"
                                placeholder="Post-Office (Post-Code)" class="form-control" required=""
                                oninvalid="this.setCustomValidity('Enter Proprietor Post Office Here')"
                                oninput="this.setCustomValidity('')">
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <input type="text" name="director_address" class="form-control"
                                placeholder=" Address (street/village)" class="form-control" required=""
                                oninvalid="this.setCustomValidity('Enter Proprietor Address Here')"
                                oninput="this.setCustomValidity('')">
                        </div>
                    </div>


                </div>
                <!-- End Propritor info -->


                <!--  -->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <h4> Institute Information </h4>

                    <input type="text" name="name" placeholder="Institute Name" class="form-control"
                        required="" oninvalid="this.setCustomValidity('Enter Your Institute Name Here')"
                        oninput="this.setCustomValidity('')">
                    <input type="text" name="nameBng" placeholder="Institute Name In Bangla" class="form-control"
                        required="" oninvalid="this.setCustomValidity('Enter Your Institute Name Here')"
                        oninput="this.setCustomValidity('')">


                    <div class="row">
                        <div class="col-md-6 col-lg-6 col-sm-12">
                            <input type="text" name="email" placeholder="Institute Email" class="form-control"
                                required="" oninvalid="this.setCustomValidity('Enter Institute Email Here')"
                                oninput="this.setCustomValidity('')">

                        </div>

                        <div class="col-md-6 col-lg-6 col-sm-12">
                            <input type="text" name="phone" placeholder="Mobile Number" class="form-control"
                                required=""
                                oninvalid="this.setCustomValidity('Enter Your Institute Mobile Number Here')"
                                oninput="this.setCustomValidity('')">
                        </div>
                    </div>


                    <input type="text" name="facebook" placeholder="Facebook Link" class="form-control"
                        required="" oninvalid="this.setCustomValidity('Enter Your Institute Facebook Link Here')"
                        oninput="this.setCustomValidity('')">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
                            <select class="form-control" name="account_type">
                                <option value="">Select Account Type</option>
                                <option value="Personal Institute"> Personal Institute</option>
                                <option value="Join Venture Institute"> Join Venture Institute</option>
                            </select>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
                            <input type="number" name="computers" placeholder="Number of Computers"
                                class="form-control" required=""
                                oninvalid="this.setCustomValidity('Enter Total Amount of Computer`s')"
                                oninput="this.setCustomValidity('')">
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <input type="number" name="age" placeholder="Institute Age's" class="form-control"
                                required="" oninvalid="this.setCustomValidity('Enter Your Institute Age`s Here')"
                                oninput="this.setCustomValidity('')">
                        </div>


                        <!-- address row -->
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <select class="form-select" name="institute_state_id" required=""
                                    oninvalid="this.setCustomValidity('Select Your Institute Division')"
                                    oninput="this.setCustomValidity('')">
                                    <option value="">Division</option>
                                    <option value="1"> Dhaka Division</option>
                                    <option value="2"> Chittagong Division</option>
                                    <option value="3"> Rajshahi Division</option>
                                    <option value="4"> Khulna Division</option>
                                    <option value="5"> Sylhet Division</option>
                                    <option value="6"> Mymensing Division</option>
                                    <option value="7"> Rangpur Division</option>
                                    <option value="8"> Barisal Division</option>
                                </select>

                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <select class="form-select" name="institute_district_id" required=""
                                    oninvalid="this.setCustomValidity('Select Your Institute Division')"
                                    oninput="this.setCustomValidity('')">
                                    <option value="">District</option>
                                    <option value="1"> Comilla</option>
                                    <option value="2"> Feni</option>
                                    <option value="3"> Brahmanbaria</option>
                                    <option value="4"> Rangamati</option>
                                    <option value="5"> Noakhali</option>
                                    <option value="6"> Chandpur</option>
                                    <option value="7"> Lakshmipur</option>
                                    <option value="8"> Chattogram</option>
                                    <option value="9"> Coxsbazar</option>
                                    <option value="10"> Khagrachhari</option>
                                    <option value="11"> Bandarban</option>
                                    <option value="12"> Sirajganj</option>
                                    <option value="13"> Pabna</option>
                                    <option value="14"> Bogura</option>
                                    <option value="15"> Rajshahi</option>
                                    <option value="16"> Natore</option>
                                    <option value="17"> Joypurhat</option>
                                    <option value="18"> Chapainawabganj</option>
                                    <option value="19"> Naogaon</option>
                                    <option value="20"> Jashore</option>
                                    <option value="21"> Satkhira</option>
                                    <option value="22"> Meherpur</option>
                                    <option value="23"> Narail</option>
                                    <option value="24"> Chuadanga</option>
                                    <option value="25"> Kushtia</option>
                                    <option value="26"> Magura</option>
                                    <option value="27"> Khulna</option>
                                    <option value="28"> Bagerhat</option>
                                    <option value="29"> Jhenaidah</option>
                                    <option value="30"> Jhalakathi</option>
                                    <option value="31"> Patuakhali</option>
                                    <option value="32"> Pirojpur</option>
                                    <option value="33"> Barisal</option>
                                    <option value="34"> Bhola</option>
                                    <option value="35"> Barguna</option>
                                    <option value="36"> Sylhet</option>
                                    <option value="37"> Moulvibazar</option>
                                    <option value="38"> Habiganj</option>
                                    <option value="39"> Sunamganj</option>
                                    <option value="40"> Narsingdi</option>
                                    <option value="41"> Gazipur</option>
                                    <option value="42"> Shariatpur</option>
                                    <option value="43"> Narayanganj</option>
                                    <option value="44"> Tangail</option>
                                    <option value="45"> Kishoreganj</option>
                                    <option value="46"> Manikganj</option>
                                    <option value="47"> Dhaka</option>
                                    <option value="48"> Munshiganj</option>
                                    <option value="49"> Rajbari</option>
                                    <option value="50"> Madaripur</option>
                                    <option value="51"> Gopalganj</option>
                                    <option value="52"> Faridpur</option>
                                    <option value="53"> Panchagarh</option>
                                    <option value="54"> Dinajpur</option>
                                    <option value="55"> Lalmonirhat</option>
                                    <option value="56"> Nilphamari</option>
                                    <option value="57"> Gaibandha</option>
                                    <option value="58"> Thakurgaon</option>
                                    <option value="59"> Rangpur</option>
                                    <option value="60"> Kurigram</option>
                                    <option value="61"> Sherpur</option>
                                    <option value="62"> Mymensingh</option>
                                    <option value="63"> Jamalpur</option>
                                    <option value="64"> Netrokona</option>
                                </select>

                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <select class="form-select" name="institute_city_id" required=""
                                    oninvalid="this.setCustomValidity('Select Your Institute City')"
                                    oninput="this.setCustomValidity('')">
                                    <option value="">City</option>
                                    <option value="1"> Barguna</option>
                                    <option value="2"> Barisal</option>
                                    <option value="3"> Bhola</option>
                                    <option value="4"> Jhalkati</option>
                                    <option value="5"> Potuakhali</option>
                                    <option value="6"> Pirojpur</option>
                                    <option value="7"> Bandorbun</option>
                                    <option value="8"> Brammonbaria</option>
                                    <option value="9"> Chandpur</option>
                                    <option value="10"> Chittagong</option>
                                    <option value="11"> Comilla</option>
                                    <option value="12"> Cox&#039;s Bazar</option>
                                    <option value="13"> Feni</option>
                                    <option value="14"> Khagrachari</option>
                                    <option value="15"> Laxmipur</option>
                                    <option value="16"> Noakhali</option>
                                    <option value="17"> Rangamati</option>
                                    <option value="18"> Dhaka</option>
                                    <option value="19"> Faridpur</option>
                                    <option value="20"> Gazipur</option>
                                    <option value="21"> Gopalganj</option>
                                    <option value="22"> Kishorganj</option>
                                    <option value="23"> Madaripur</option>
                                    <option value="24"> Manikganj</option>
                                    <option value="25"> Munshiganj</option>
                                    <option value="26"> Narayanganj</option>
                                    <option value="27"> Narshingdi</option>
                                    <option value="28"> Rajbari</option>
                                    <option value="29"> Shariatpur</option>
                                    <option value="30"> Tangail</option>
                                    <option value="31"> Bagerhat</option>
                                    <option value="32"> Chuadanga</option>
                                    <option value="33"> Jessore</option>
                                    <option value="34"> Jhinaidaha</option>
                                    <option value="35"> Khulna</option>
                                    <option value="36"> Kushtia</option>
                                    <option value="37"> Magura</option>
                                    <option value="38"> Meherpur</option>
                                    <option value="39"> Norail</option>
                                    <option value="40"> Sathkira</option>
                                    <option value="41"> Jamalpur</option>
                                    <option value="42"> Netrokuna</option>
                                    <option value="43"> Mymensing</option>
                                    <option value="44"> Sherpur</option>
                                    <option value="45"> Bogra</option>
                                    <option value="46"> Joypurhat</option>
                                    <option value="47"> Nouga</option>
                                    <option value="48"> Nator</option>
                                    <option value="49"> Nobabgonj</option>
                                    <option value="50"> Pabna</option>
                                    <option value="51"> Rajshahi</option>
                                    <option value="52"> Shirajganj</option>
                                    <option value="53"> Dinajpur</option>
                                    <option value="54"> Gaibanda</option>
                                    <option value="55"> Kurigram</option>
                                    <option value="56"> Lalmonirhat</option>
                                    <option value="57"> Nilfamari</option>
                                    <option value="58"> Panchogor</option>
                                    <option value="59"> Rangpur</option>
                                    <option value="60"> Tegorgaon</option>
                                    <option value="61"> Hobiganj</option>
                                    <option value="62"> Moulovibazar</option>
                                    <option value="63"> Sunamganj</option>
                                    <option value="64"> Sylhet</option>
                                </select>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <input type="text" name="institute_upazila" class="form-control"
                                    placeholder="Upazila" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Institute Upazila Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <input type="text" name="institute_post_office" class="form-control"
                                    placeholder="Post-Office (Post-Code)" class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Institute Post Office Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <input type="text" name="address" placeholder=" Address(street/village)"
                                    class="form-control" required=""
                                    oninvalid="this.setCustomValidity('Enter Your Institute Address Here')"
                                    oninput="this.setCustomValidity('')">
                            </div>

                        </div>
                        <!-- end address -->




                    </div>

                </div>

            </div>
            <!--  -->

            <div class="row">
                <h4>Documents</h4>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="input_file">
                        <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" id="profilePhoto">
                        <p> Profile Picture</p>
                    </div>
                    <input type="file" name="pic" onchange="profile(event)" class="form-control" required=""
                        oninvalid="this.setCustomValidity('Upload Propritor Image')" oninput="this.setCustomValidity('')">
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="input_file">
                        <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" id="nidCard">
                        <p> NID Card</p>
                    </div>
                    <input type="file" name="nid" onchange="nidInput(event)" class="form-control" required=""
                        oninvalid="this.setCustomValidity('Upload NID Card Copy')" oninput="this.setCustomValidity('')">
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="input_file">
                        <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" id="trade">
                        <p> Treade License</p>
                    </div>
                    <input type="file" name="trade_licence" onchange="tradeInput(event)" class="form-control"
                        required="" oninvalid="this.setCustomValidity('Upload Trade License Copy')"
                        oninput="this.setCustomValidity('')">
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="input_file">
                        <img src="<?php echo e(asset('frontend/assets/admin/images/students/11.png')); ?>" id="signature">
                        <p>Signature</p>
                    </div>
                    <input type="file" name="signature" onchange="signatureInput(event)" class="form-control"
                        required="" oninvalid="this.setCustomValidity('Upload Propritor Valid signature')"
                        oninput="this.setCustomValidity('')">
                </div>

            </div>

            <div class="my_glass_button ">
                <div>
                    <button type="submit"> Apply Now</button>
                </div>
            </div>
        </form>
    </section>

    <div style="clear: both;"></div>
    &nbsp;
    &nbsp;
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var stickyOffset = $('.sticky').offset().top;

        $(window).scroll(function() {
            var sticky = $('.sticky'),
                scroll = $(window).scrollTop();

            if (scroll >= stickyOffset) sticky.addClass('fixed');
            else sticky.removeClass('fixed');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Code\coxs\resources\views/frontend/center_registration.blade.php ENDPATH**/ ?>