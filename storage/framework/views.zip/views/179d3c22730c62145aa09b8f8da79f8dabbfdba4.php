
<?php $__env->startSection('admin'); ?>
    <div class="page-content">
        <div class="container-fluid">

            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong><?php echo e($message); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>


            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">Employee List</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">

                                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">Employee </li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <h4 class="card-title">All Employee info Goers Here</h4>
                            <hr />

                            <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>SL</th>

                                        <th>Name</th>
                                        <th>Initial Name</th>
                                        <th>Email</th>

                                        <th>Department</th>

                                        <th>Status</th>

                                        <th class="text-right">Action</th>
                                    </tr>
                                </thead>


                                <tbody>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>

                                            <td><?php echo e($employee->name); ?></td>
                                            <td><?php echo e($employee->initial_name); ?></td>

                                            <td><?php echo e($employee->email); ?></td>

                                            <td><?php echo e($employee->department); ?></td>

                                            <td>
                                                <?php if($employee->status == 1): ?>
                                                    <span
                                                        class="badge badge-pill badge-soft-success font-size-12">Published</span>
                                                <?php elseif($employee->status == 0): ?>
                                                    <span
                                                        class="badge badge-pill badge-soft-warning font-size-12">Unpublished</span>
                                                <?php else: ?>
                                                    <span class="mj_btn btn btn-warning">Pending</span>
                                                <?php endif; ?>
                                            </td>


                                            <td class="text-right">
                                                <a href="<?php echo e(route('employee.update-status', ['id' => $employee->id])); ?>"
                                                    class="btn <?php echo e($employee->status == 1 ? 'btn-info' : 'btn-warning'); ?> btn-sm">
                                                    <i class="fas fa-arrow-alt-circle-up"></i>
                                                </a>
                                                <a href="<?php echo e(route('employee.detail', ['id' => $employee->id])); ?>"
                                                    class="btn btn-primary btn-sm">
                                                    <i class="fas fa-book-open"></i>
                                                </a>
                                                <a href="<?php echo e(route('employee.edit', $employee->id)); ?>"
                                                    class="btn btn-success btn-sm">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="" class="btn btn-danger btn-sm"
                                                    onclick="event.preventDefault(); document.getElementById('employeeForm<?php echo e($employee->id); ?>').submit();">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>

                                                <form method="POST"
                                                    action="<?php echo e(route('employee.destroy', ['id' => $employee->id])); ?>"
                                                    id="employeeForm<?php echo e($employee->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                </form>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\XAMPP\htdocs\online-shop\resources\views/admin/employee/show.blade.php ENDPATH**/ ?>