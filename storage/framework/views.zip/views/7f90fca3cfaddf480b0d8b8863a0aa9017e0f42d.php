
<?php $__env->startSection('css'); ?>
    <style type="text/css">
        nav {
            width: 100%;
            z-index: 5;
            text-align: center;
        }

            {
            color: #fff !important;
        }



        nav ul li {
            padding: 10px 10px;
            transition: 0.4s;
        }

        nav ul li a {
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            color: #fff;
        }

        nav ul li .active {
            color: #ffd900;
        }

        nav ul li:hover a {
            color: #fff;
        }

        @media (max-width: 767px) {

            nav {
                /*background: #000;*/
                margin-bottom: 30px;
            }

            nav button {
                background: #f00;
                color: #4e00cc;

            }

        }

        .fixed {
            position: fixed;
            top: 0;
        }

        * {
            box-sizing: border-box;
        }

        #parent {
            color: #fff;
            padding: 10px;
            width: 100%;

            text-align: center;
        }

        .fab {
            padding: 20px;
            font-size: 30px;
            color: #fff;
            width: 50px;
            text-align: center;
            text-decoration: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mian'); ?>
    <?php echo $__env->make('frontend.body.top_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.body.slide_other', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="title_bar">
        <div class="container">
            <div>
                <h4> <i class="fas fa-user-graduate"></i> All Courses </h4>
            </div>
        </div>
    </section>

    <section class="free_course">
        <div class="bg-blur">
            <div class="container">
                <h1>Off Line Course</h1>
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/mnbvcx.jpg')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">OFFICE MANAGEMENT </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">2000</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/mnbv.jpg')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">COMPUTER BASIC </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">2000</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/mnb.jpg')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">ADVANCED EXCEL</h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">2000</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/mn.png')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">DIPLOMA IN COMPUTER SCIENCE </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">2000</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>


                </div>


            </div>


        </div>
        </div>
    </section>

    <section class="paid_course" id="our_courses">
        <div class="bg-blur">
            <div class="container">
                <h1>Our Paid Courses</h1>

                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="courses/details.html" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/12.jpg')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">Digital Marketing </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">Discount: 750/-</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="courses/details.html" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/123.jpg')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">Artificial Intelligence </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">Discount: 750/-</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="courses/details.html" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/1234.jpg')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">AWS Course </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">Discount: 750/-</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="courses/details.html" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/12345.png')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">Auto Cad Course </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">Discount: 750/-</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>


                </div>

                

            </div>
        </div>
    </section>

    <section class="free_course">
        <div class="bg-blur">
            <div class="container">
                <h1>Our Free Tutorials </h1>
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/download.png')); ?>" class="img">
                                <div class="card_body">
                                    <h4 class="title">Office Application </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">Free</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/photoshop-history.jpg')); ?>"
                                    class="img">
                                <div class="card_body">
                                    <h4 class="title">Adobe Photoshop </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">Free</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/Hardware-vs-Software.jpg')); ?>"
                                    class="img">
                                <div class="card_body">
                                    <h4 class="title">Hardware &amp; Software </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">Free</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="margin-bottom:15px;">
                        <a href="#" style="text-decoration:none;">
                            <div class="my_card">
                                <img src="<?php echo e(asset('frontend/assets/image/course/howtogetexcelforfree1_thumb800.png')); ?>"
                                    class="img">
                                <div class="card_body">
                                    <h4 class="title">Microsoft Excel </h4>
                                    <p class="prize">Prize: 2550/-</p>
                                    <p class="discount_prize">Free</p>
                                    <span class="total_time"><i class="far fa-clock"></i> 32+ hr </span>
                                    <span class="total_video"><i class="fas fa-video"></i> 50+ </span>
                                </div>
                            </div>
                        </a>
                    </div>


                </div>


            </div>

            
        </div>
        </div>
    </section>

    <div style="clear: both;"></div>
    &nbsp;
    &nbsp;
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var stickyOffset = $('.sticky').offset().top;

        $(window).scroll(function() {
            var sticky = $('.sticky'),
                scroll = $(window).scrollTop();

            if (scroll >= stickyOffset) sticky.addClass('fixed');
            else sticky.removeClass('fixed');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Code\coxs\resources\views/frontend/course.blade.php ENDPATH**/ ?>